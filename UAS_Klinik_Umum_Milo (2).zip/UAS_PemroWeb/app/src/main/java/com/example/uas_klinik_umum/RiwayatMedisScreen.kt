package com.example.uas_klinik_umum

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.History
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.uas_klinik_umum.network.ApiClient
import com.example.uas_klinik_umum.network.RiwayatPendaftaran
import com.example.uas_klinik_umum.utils.SessionManager
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RiwayatMedisScreen(
    sessionManager: SessionManager,
    onBack: () -> Unit
) {
    val coroutineScope = rememberCoroutineScope()
    var isLoading by remember { mutableStateOf(true) }
    var listRiwayat by remember { mutableStateOf<List<RiwayatPendaftaran>>(emptyList()) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    val idUserStr = sessionManager.fetchUserId()
    val idUser = idUserStr?.toString()?.toIntOrNull() ?: 0

    LaunchedEffect(Unit) {
        coroutineScope.launch {
            try {
                val response = ApiClient.apiService.getRiwayat(idUser)
                if (response.isSuccessful && response.body()?.status == true) {
                    listRiwayat = response.body()?.data ?: emptyList()
                } else {
                    errorMessage = response.body()?.message ?: "Belum ada riwayat."
                }
            } catch (e: Exception) {
                errorMessage = "Koneksi Error: ${e.localizedMessage}"
            } finally {
                isLoading = false
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Riwayat Kunjungan", color = Color.White) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            imageVector = Icons.Default.ArrowBack,
                            contentDescription = "Back",
                            tint = Color.White
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary
                )
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(Color(0xFFF8F9FA))
        ) {
            if (isLoading) {
                CircularProgressIndicator(modifier = Modifier.align(Alignment.Center))
            } else if (listRiwayat.isEmpty()) {
                Column(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // PERBAIKAN DI SINI: size dipindah ke Modifier
                    Icon(
                        imageVector = Icons.Default.History,
                        contentDescription = null,
                        modifier = Modifier.size(64.dp),
                        tint = Color.LightGray
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(errorMessage ?: "Data kosong", color = Color.Gray)
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(listRiwayat.size) { index ->
                        val riwayat = listRiwayat[index]
                        ItemRiwayatCard(riwayat)
                    }
                }
            }
        }
    }
}

@Composable
fun ItemRiwayatCard(riwayat: RiwayatPendaftaran) {
    val statusColor = if (riwayat.status_layanan.contains("SELESAI", ignoreCase = true))
        Color(0xFF2E7D32) else Color(0xFFC62828)

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(riwayat.tanggal_kunjungan, fontSize = 12.sp, color = Color.Gray)
                Text(
                    riwayat.status_layanan,
                    color = statusColor,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp
                )
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(riwayat.nama_dokter, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Text(riwayat.spesialisasi, fontSize = 14.sp, color = Color.DarkGray)

            HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), thickness = 0.5.dp, color = Color.LightGray)

            Text("Keluhan:", fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
            Text(riwayat.keluhan_awal ?: "-", fontSize = 13.sp)
        }
    }
}