package com.example.uas_klinik_umum.network

import com.google.gson.annotations.SerializedName // Pastikan baris ini ditambahkan di atas
data class LoginRequest(val email: String, val password: String)

data class RegisterAccountRequest(val email: String, val password: String)

data class LoginResponse(
    val status: Boolean,
    val message: String?,
    val is_profile_complete: Boolean?,
    val token: String?,
    val data: UserData?
)

data class UserData(
    val id_user: Int,
    val email: String,
    val role: String, // pasien, dokter, admin
    val nama: String?
)

// ... (kode LoginRequest dkk biarkan saja)

data class RegisterRequest(
    val email: String,
    val password: String,
    val nama_lengkap: String, // Harus sama dengan $data['nama_lengkap'] di PHP
    val nik: String,
    val jenis_kelamin: String,
    val tanggal_lahir: String,
    val nomor_telepon: String,
    val alamat: String
)

data class ForgotPasswordRequest(
    val action: String, // "request_otp", "verify_otp", atau "reset_password"
    val email: String,
    val otp: String? = null,
    val new_password: String? = null
)

data class GeneralResponse(
    val status: Boolean,
    val message: String
)

data class RegisterAccountResponse(
    val status: Boolean,
    val message: String?,
    val id_user: Int? // Server akan mengembalikan ID User yang baru dibuat
)

// Request untuk Tahap 2 (Isi Profil + Golongan Darah & Alergi)


data class ProfilPasienRequest(
    @SerializedName("id_user") val idUser: Int,
    @SerializedName("nama_lengkap") val nama: String,
    @SerializedName("nik") val nik: String,
    @SerializedName("jenis_kelamin") val jk: String,
    @SerializedName("tanggal_lahir") val tglLahir: String,
    @SerializedName("nomor_telepon") val telp: String,
    @SerializedName("alamat") val alamat: String,
    @SerializedName("golongan_darah") val golDarah: String,
    @SerializedName("alergi_obat") val alergi: String
)

data class Dokter(
    val id_dokter: Int,
    val nama_dokter: String,
    val spesialisasi: String,
    val nomor_telepon: String?,
    val tarif_konsultasi: Int?,
    val jadwal: List<JadwalDokter> // <-- Ini mengubah teks menjadi List terstruktur
)

data class JadwalDokter(
    val hari: String,
    val jam_mulai: String,
    val jam_selesai: String
)

data class GetDokterResponse(
    val status: Boolean,
    val data: List<Dokter>
)

data class PendaftaranRequest(
    val id_user: Int,
    val id_dokter: Int,
    val tanggal_kunjungan: String,
    val jam_kunjungan: String,
    val keluhan: String
)
// Cari bagian TiketAntrian dan PendaftaranResponse, lalu ganti dengan ini:

data class PendaftaranResponse(
    val status: Boolean,
    val message: String?,
    @SerializedName("nomor_antrean", alternate = ["nomor_antrian"]) // Mendukung ejaan 'e' dan 'i'
    val nomor_antrean: Int?,
    val id_pendaftaran: Int?
)

data class TiketAntrian(
    val id_pendaftaran: Int,
    @SerializedName("nomor_antrean", alternate = ["nomor_antrian"])
    val nomor_antrean: Int,
    val tanggal_kunjungan: String,
    val jam_kunjungan: String,
    val keluhan_awal: String,
    val status_layanan: String,
    val nama_dokter: String,
    val spesialisasi: String,

    val diagnosa: String?,
    val tindakan: String?,
    val total_tagihan: Int?
)

data class GetTiketResponse(
    val status: Boolean,
    val message: String?,
    val data: List<TiketAntrian>
)

// ==========================================
// TAMBAHAN UNTUK FITUR RIWAYAT PENDAFTARAN
// ==========================================

data class RiwayatPendaftaran(
    val id_pendaftaran: Int,
    val nomor_antrean: Int,
    val tanggal_kunjungan: String,
    val jam_kunjungan: String,
    val keluhan_awal: String,
    val status_layanan: String,
    val nama_dokter: String,
    val spesialisasi: String,

    // Detail Medis Tambahan
    val gejala: String?,
    val penyakit: String?,
    val diagnosa: String?,
    val tindakan: String?,
    val total_tagihan: Int?
)

data class GetRiwayatResponse(
    val status: Boolean,
    val message: String?,
    val data: List<RiwayatPendaftaran>?
)

data class AntreanRequest(
    val id_user: Int
)

data class AntreanResponse(
    val status: Boolean,
    val message: String?,
    val data: List<AntreanItem>
)

data class AntreanItem(
    val idPendaftaran: Int,
    val noAntrean: Int,
    val namaPasien: String,
    val namaDokter: String? = null,
    val spesialisasi: String? = null,
    val tanggalKunjungan: String? = null,
    val jamKunjungan: String? = null,
    val keluhan: String,
    val status: String,
    val tarifKonsultasi: Int? = 0 // [BARU] Menangkap harga konsultasi dari database
)

data class Obat(
    val id_obat: Int,
    val nama_obat: String,
    val satuan: String,
    val harga_jual: Double,
    val stok: Int
)

data class GetObatResponse(
    val status: Boolean,
    val message: String?,
    val data: List<Obat>
)

data class Pembayaran(
    val id_pembayaran: Int,
    val id_pendaftaran: Int,
    val total_tagihan: Double,
    val jenis_pasien: String,
    val nomor_kartu: String?,
    val status_bayar: String,
    val tanggal_bayar: String?,
    val nama_pasien: String? = null
)

data class GetPembayaranResponse(
    val status: Boolean,
    val message: String?,
    val data: List<Pembayaran>
)

data class SimpanPemeriksaanRequest(
    val id_pendaftaran: Int,
    val gejala: String,
    val penyakit: String,
    val diagnosa: String,
    val obat: String,
    val total_bayar: Int
)

data class KasirItem(
    val idPendaftaran: Int,
    val noAntrean: String,
    val namaPasien: String,
    val diagnosa: String,
    val tindakanObat: String,
    val totalTagihan: Int
)

data class KasirResponse(
    val status: Boolean,
    val message: String?,
    val data: List<KasirItem>
)

data class RiwayatDokter(
    val id_pendaftaran: Int,
    val tanggal_kunjungan: String,
    val jam_kunjungan: String,
    val nama_pasien: String,
    val jenis_kelamin: String,
    val diagnosa: String,
    val tindakan: String
)

data class GetRiwayatDokterResponse(
    val status: Boolean,
    val message: String?,
    val data: List<RiwayatDokter>
)

// ==========================================================
// [BARU] WADAH UNTUK KELOLA USER & LAPORAN ADMIN
// ==========================================================

data class UserProfile(
    val id_user: Int,
    val role: String,
    val email: String,
    val nama_lengkap: String?,
    val jenis_kelamin: String?,
    val spesialisasi: String?,
    val nomor_telepon: String?,
    val nik: String? = null,
    val tanggal_lahir: String? = null,
    val alamat: String? = null,
    val golongan_darah: String? = null,
    val alergi_obat: String? = null
)

data class GetUsersResponse(
    val status: Boolean,
    val message: String?,
    val data: List<UserProfile>
)

data class LaporanBulanan(
    val bulan: String,
    val tahun: String,
    val total_pendapatan: Double,
    val total_pasien_selesai: Int,
    val total_pasien_batal: Int
)

data class GetLaporanResponse(
    val status: Boolean,
    val message: String?,
    val data: List<LaporanBulanan>
)

data class KonfirmasiPembayaranRequest(
    val id_pendaftaran: Int,
    val total_tagihan: Double,
    val jenis_pasien: String,
    val nomor_kartu: String? = null
)

data class AsuransiPusat(
    val id_asuransi_pusat: Int,
    val nik_peserta: String,
    val nomor_kartu: String,
    val nama_asuransi: String,
    val status_kepesertaan: String
)

data class GetAsuransiResponse(
    val status: Boolean,
    val message: String?,
    val data: List<AsuransiPusat>
)

data class MitraAsuransiResponse(
    val status: Boolean,
    val message: String?,
    val data: List<String>
)