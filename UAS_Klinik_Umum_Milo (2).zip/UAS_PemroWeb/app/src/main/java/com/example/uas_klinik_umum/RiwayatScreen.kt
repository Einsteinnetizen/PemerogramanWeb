package com.example.uas_klinik_umum

import android.app.DatePickerDialog
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.uas_klinik_umum.network.ApiClient
import com.example.uas_klinik_umum.network.RiwayatPendaftaran
import kotlinx.coroutines.launch
import java.util.Calendar

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RiwayatScreen(idUser: Int) {
    val coroutineScope = rememberCoroutineScope()
    val context = LocalContext.current
    var riwayatList by remember { mutableStateOf<List<RiwayatPendaftaran>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }

    // State untuk memisahkan input Tanggal (DD MM YYYY)
    var day by remember { mutableStateOf("") }
    var month by remember { mutableStateOf("") }
    var year by remember { mutableStateOf("") }

    LaunchedEffect(idUser) {
        coroutineScope.launch {
            try {
                val response = ApiClient.apiService.getRiwayat(idUser)
                if (response.isSuccessful) {
                    riwayatList = response.body()?.data ?: emptyList()
                }
            } catch (e: Exception) {
                // Tangani error
            } finally {
                isLoading = false
            }
        }
    }

    // LOGIKA KALENDER (DATE PICKER Bawaan Android)
    val calendar = Calendar.getInstance()
    val datePickerDialog = DatePickerDialog(
        context,
        { _, selectedYear, selectedMonth, selectedDay ->
            year = selectedYear.toString()
            // Format angka otomatis jadi 2 digit (contoh: 5 jadi "05")
            month = String.format("%02d", selectedMonth + 1)
            day = String.format("%02d", selectedDay)
        },
        calendar.get(Calendar.YEAR),
        calendar.get(Calendar.MONTH),
        calendar.get(Calendar.DAY_OF_MONTH)
    )

    // FITUR FILTER CERDAS: Filter berdasarkan DD, MM, YYYY secara dinamis
    val filteredList = riwayatList.filter { riwayat ->
        val date = riwayat.tanggal_kunjungan // Asumsi format dari database YYYY-MM-DD
        val parts = date.split("-")

        if (parts.size == 3) {
            val dbYear = parts[0]
            val dbMonth = parts[1]
            val dbDay = parts[2]

            val matchYear = year.isEmpty() || dbYear.contains(year)
            val matchMonth = month.isEmpty() || dbMonth.contains(month)
            val matchDay = day.isEmpty() || dbDay.contains(day)

            matchYear && matchMonth && matchDay
        } else {
            true // Jika format database berbeda, tampilkan saja semua
        }
    }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text("Riwayat Medis", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(16.dp))

        // UI PENCARIAN TANGGAL (DD MM YYYY + KALENDER)
        Text("Cari Berdasarkan Tanggal", fontSize = 14.sp, color = Color.Gray, fontWeight = FontWeight.SemiBold)
        Spacer(modifier = Modifier.height(8.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = day,
                onValueChange = { if (it.length <= 2) day = it }, // Maks 2 digit
                label = { Text("DD") },
                modifier = Modifier.weight(1f),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                singleLine = true
            )
            OutlinedTextField(
                value = month,
                onValueChange = { if (it.length <= 2) month = it }, // Maks 2 digit
                label = { Text("MM") },
                modifier = Modifier.weight(1f),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                singleLine = true
            )
            OutlinedTextField(
                value = year,
                onValueChange = { if (it.length <= 4) year = it }, // Maks 4 digit
                label = { Text("YYYY") },
                modifier = Modifier.weight(1.5f),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                singleLine = true
            )

            // TOMBOL KALENDER
            IconButton(
                onClick = { datePickerDialog.show() },
                modifier = Modifier
                    .size(54.dp)
                    .background(MaterialTheme.colorScheme.primaryContainer, shape = RoundedCornerShape(8.dp))
            ) {
                Icon(
                    Icons.Default.DateRange,
                    contentDescription = "Pilih Tanggal",
                    tint = MaterialTheme.colorScheme.onPrimaryContainer
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        if (isLoading) {
            CircularProgressIndicator(modifier = Modifier.align(Alignment.CenterHorizontally))
        } else if (filteredList.isEmpty()) {
            Text("Tidak ada riwayat ditemukan pada tanggal tersebut.", color = Color.Gray)
        } else {
            LazyColumn(modifier = Modifier.fillMaxSize()) {
                items(filteredList) { riwayat ->
                    Card(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                Text("Tanggal: ${riwayat.tanggal_kunjungan}", fontWeight = FontWeight.Bold)
                                Text("Status: ${riwayat.status_layanan}", color = if (riwayat.status_layanan == "SELESAI") Color(0xFF388E3C) else Color.Red)
                            }
                            HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))
                            Text("Dokter: ${riwayat.nama_dokter} (${riwayat.spesialisasi})")
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("Gejala: ${riwayat.gejala ?: "-"}", fontSize = 14.sp)
                            Text("Penyakit: ${riwayat.penyakit ?: "-"}", fontSize = 14.sp)
                            Text("Diagnosa: ${riwayat.diagnosa ?: "-"}", fontSize = 14.sp)
                            Text("Tindakan/Obat: ${riwayat.tindakan ?: "-"}", fontSize = 14.sp)
                            Spacer(modifier = Modifier.height(8.dp))

                            val formatter = java.text.NumberFormat.getNumberInstance(java.util.Locale("id", "ID"))
                            Text("Total Bayar: Rp ${formatter.format(riwayat.total_tagihan ?: 0)}", fontWeight = FontWeight.Bold, color = Color(0xFFD32F2F))
                        }
                    }
                }
            }
        }
    }
}