package com.example.uas_klinik_umum

import android.app.DatePickerDialog
import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.MedicalServices
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.uas_klinik_umum.network.AntreanItem
import com.example.uas_klinik_umum.network.ApiClient
import com.example.uas_klinik_umum.network.KasirItem
import com.example.uas_klinik_umum.network.Obat
import com.example.uas_klinik_umum.network.Pembayaran
import com.example.uas_klinik_umum.utils.SessionManager
import kotlinx.coroutines.launch
import java.util.Calendar
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.People
import com.example.uas_klinik_umum.network.UserProfile
import com.example.uas_klinik_umum.network.LaporanBulanan
import android.print.PrintAttributes
import android.print.PrintManager
import android.webkit.WebView
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.Security
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.TextRange
import com.example.uas_klinik_umum.network.KonfirmasiPembayaranRequest
import com.example.uas_klinik_umum.network.AsuransiPusat
import androidx.compose.foundation.layout.size

class AdminDashboardActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val sessionManager = SessionManager(this)
        setContent {
            MaterialTheme {
                AdminMainScreen(sessionManager)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminMainScreen(sessionManager: SessionManager) {
    var selectedTab by remember { mutableIntStateOf(0) }
    var refreshTrigger by remember { mutableIntStateOf(0) }
    val context = LocalContext.current
    val tabs = listOf("Pembayaran", "Stok Obat", "Antrean", "User", "Laporan")
    val icons = listOf(Icons.Default.Payments, Icons.Default.MedicalServices, Icons.AutoMirrored.Filled.List, Icons.Default.People, Icons.Default.Assessment)

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Admin Dashboard") },
                actions = {
                    IconButton(onClick = { refreshTrigger++ }) {
                        Icon(imageVector = Icons.Default.Refresh, contentDescription = "Refresh")
                    }
                    IconButton(onClick = {
                        sessionManager.clearSession()
                        val intent = Intent(context, LoginActivity::class.java)
                        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
                        context.startActivity(intent)
                    }) {
                        Icon(imageVector = Icons.AutoMirrored.Filled.Logout, contentDescription = "Logout")
                    }
                }
            )
        },
        bottomBar = {
            NavigationBar {
                tabs.forEachIndexed { index, title ->
                    NavigationBarItem(
                        icon = { Icon(icons[index], contentDescription = title) },
                        label = { Text(title) },
                        selected = selectedTab == index,
                        onClick = { selectedTab = index }
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(modifier = Modifier.padding(innerPadding).fillMaxSize()) {
            when (selectedTab) {
                0 -> PaymentScreen(refreshTrigger)
                1 -> MedicineScreen(refreshTrigger)
                2 -> QueueScreen(refreshTrigger)
                3 -> UserScreen(refreshTrigger)
                4 -> ReportScreen(refreshTrigger)
                5 -> AsuransiScreen(refreshTrigger)
            }
        }
    }
}

// ======================================================================
// PEMBAYARAN (KASIR & RIWAYAT TRANSAKSI DGN FILTER KALENDER)
// ======================================================================
@Composable
fun PaymentScreen(refreshTrigger: Int) {
    var selectedSubTab by remember { mutableIntStateOf(0) }
    Column(modifier = Modifier.fillMaxSize()) {
        TabRow(
            selectedTabIndex = selectedSubTab,
            containerColor = MaterialTheme.colorScheme.primaryContainer,
            contentColor = MaterialTheme.colorScheme.onPrimaryContainer
        ) {
            Tab(selected = selectedSubTab == 0, onClick = { selectedSubTab = 0 }, text = { Text("Antrean Kasir", fontWeight = FontWeight.Bold) })
            Tab(selected = selectedSubTab == 1, onClick = { selectedSubTab = 1 }, text = { Text("Riwayat Transaksi", fontWeight = FontWeight.Bold) })
        }
        Box(modifier = Modifier.fillMaxSize().weight(1f)) {
            if (selectedSubTab == 0) AntreanKasirAktif(refreshTrigger)
            else RiwayatTransaksiScreen(refreshTrigger)
        }
    }
}

@Composable
fun AntreanKasirAktif(refreshTrigger: Int) {
    var kasirItems by remember { mutableStateOf<List<KasirItem>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }
    var selectedKasir by remember { mutableStateOf<KasirItem?>(null) } // Menyimpan data kasir yang di-klik
    val scope = rememberCoroutineScope()
    val context = LocalContext.current

    val fetchData = suspend {
        isLoading = true
        try {
            val response = ApiClient.apiService.getAntreanKasir()
            kasirItems = if (response.isSuccessful && response.body()?.status == true) response.body()?.data ?: emptyList() else emptyList()
        } catch (e: Exception) { Toast.makeText(context, "Koneksi Gagal: ${e.message}", Toast.LENGTH_SHORT).show() }
        finally { isLoading = false }
    }

    LaunchedEffect(refreshTrigger) { fetchData() }

    if (isLoading) Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
    else if (kasirItems.isEmpty()) Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("Tidak ada pasien di tahap pembayaran.", color = Color.Gray) }
    else {
        LazyColumn(Modifier.fillMaxSize().padding(16.dp)) {
            items(kasirItems) { item ->
                Card(modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp), elevation = CardDefaults.cardElevation(4.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                    Column(Modifier.padding(16.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(item.noAntrean, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, fontSize = 18.sp)
                            val formatter = java.text.NumberFormat.getNumberInstance(java.util.Locale("id", "ID"))
                            Text("Rp ${formatter.format(item.totalTagihan)}", fontWeight = FontWeight.Bold, color = Color(0xFFD32F2F), fontSize = 18.sp)
                        }
                        Spacer(Modifier.height(8.dp))
                        Text("Pasien: ${item.namaPasien}", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        Text("Obat/Tindakan: ${item.tindakanObat}", style = MaterialTheme.typography.bodyMedium, color = Color.Gray)
                        Spacer(Modifier.height(16.dp))

                        // [PERBAIKAN] Tombol ini sekarang membuka Pop-Up Kasir, BUKAN langsung melunaskan
                        Button(
                            onClick = { selectedKasir = item },
                            modifier = Modifier.align(Alignment.End)
                        ) { Text("PROSES PEMBAYARAN", fontWeight = FontWeight.Bold) }
                    }
                }
            }
        }
    }

    if (selectedKasir != null) {
        DialogKonfirmasiPembayaran(
            item = selectedKasir!!,
            onDismiss = { selectedKasir = null },
            onConfirm = { id, totalTagihan, jenisPasien, nomorKartu ->
                scope.launch {
                    try {
                        val request = KonfirmasiPembayaranRequest(id, totalTagihan, jenisPasien, nomorKartu)
                        val resp = ApiClient.apiService.konfirmasiPembayaran(request)
                        if (resp.isSuccessful && resp.body()?.status == true) {
                            Toast.makeText(context, "Lunas!", Toast.LENGTH_SHORT).show()
                            fetchData()
                            selectedKasir = null
                        } else { Toast.makeText(context, "Gagal: ${resp.body()?.message}", Toast.LENGTH_SHORT).show() }
                    } catch (e: Exception) { Toast.makeText(context, "Error: ${e.message}", Toast.LENGTH_SHORT).show() }
                }
            }
        )
    }
}

// ======================================================================
// [BARU] POP UP KONFIRMASI KASIR (INPUT HARGA & BPJS)
// ======================================================================
// ======================================================================
// POP UP KONFIRMASI KASIR (DENGAN DISKON OTOMATIS BPJS)
// ======================================================================
// ======================================================================
// POP UP KONFIRMASI KASIR (DENGAN DISKON OTOMATIS BPJS & VALIDASI)
// ======================================================================
@Composable
fun DialogKonfirmasiPembayaran(
    item: KasirItem,
    onDismiss: () -> Unit,
    onConfirm: (Int, Double, String, String?) -> Unit
) {
    var isHanyaKonsultasi by remember { mutableStateOf(false) }
    var biayaObat by remember { mutableStateOf(TextFieldValue("")) }
    var jenisPasien by remember { mutableStateOf("Umum") }
    var nomorKartu by remember { mutableStateOf("") }

    val scope = rememberCoroutineScope()
    var isCheckingCard by remember { mutableStateOf(false) }
    val context = LocalContext.current

    val formatter = java.text.NumberFormat.getNumberInstance(java.util.Locale("id", "ID"))
    val tarifKonsultasi = item.totalTagihan

    val cleanBiaya = if (isHanyaKonsultasi) 0L else (biayaObat.text.replace(Regex("[^0-9]"), "").toLongOrNull() ?: 0L)
    val subTotal = tarifKonsultasi + cleanBiaya

    val potonganBPJS = if (jenisPasien == "BPJS") subTotal else 0L
    val grandTotal = subTotal - potonganBPJS

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Proses Kasir", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Pasien: ${item.namaPasien}", fontWeight = FontWeight.Bold)
                Text("Resep: ${item.tindakanObat}", color = Color.Gray, fontSize = 12.sp)
                HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))

                Text("Tarif Konsultasi: Rp ${formatter.format(tarifKonsultasi)}")

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = isHanyaKonsultasi, onCheckedChange = { isHanyaKonsultasi = it })
                    Text("Hanya Konsultasi (Tanpa Obat)", fontSize = 14.sp)
                }

                if (!isHanyaKonsultasi) {
                    OutlinedTextField(
                        value = biayaObat,
                        onValueChange = { newValue ->
                            val cleanString = newValue.text.replace(Regex("[^0-9]"), "")
                            if (cleanString.isNotEmpty()) {
                                val parsed = cleanString.toLongOrNull() ?: 0L
                                val formattedNumber = formatter.format(parsed)
                                biayaObat = TextFieldValue(text = formattedNumber, selection = TextRange(formattedNumber.length))
                            } else { biayaObat = TextFieldValue("") }
                        },
                        label = { Text("Input Total Harga Obat") }, prefix = { Text("Rp ") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth(), singleLine = true
                    )
                }

                Text("Jenis Pasien:", fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp))
                Row {
                    Row(verticalAlignment = Alignment.CenterVertically) { RadioButton(selected = jenisPasien == "Umum", onClick = { jenisPasien = "Umum" }); Text("Umum") }
                    Spacer(Modifier.width(16.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) { RadioButton(selected = jenisPasien == "BPJS", onClick = { jenisPasien = "BPJS" }); Text("BPJS") }
                }

                if (jenisPasien == "BPJS") {
                    OutlinedTextField(
                        value = nomorKartu,
                        onValueChange = { nomorKartu = it },
                        label = { Text("Nomor Kartu BPJS") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        isError = nomorKartu.trim().isEmpty()
                    )
                    if (nomorKartu.trim().isEmpty()) {
                        Text("Nomor kartu wajib diisi!", color = Color.Red, fontSize = 11.sp)
                    } else {
                        Text("Sistem akan memverifikasi kartu ke database pusat.", color = Color.Gray, fontSize = 11.sp)
                    }
                }

                HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

                if (jenisPasien == "BPJS") {
                    Text(text = "Subtotal: Rp ${formatter.format(subTotal)}", color = Color.Gray, fontSize = 14.sp, textDecoration = androidx.compose.ui.text.style.TextDecoration.LineThrough)
                    Text("Ditanggung BPJS: - Rp ${formatter.format(potonganBPJS)}", color = Color(0xFF2E7D32), fontSize = 14.sp)
                }

                Text("GRAND TOTAL: Rp ${formatter.format(grandTotal)}", fontWeight = FontWeight.ExtraBold, color = if(grandTotal == 0L) Color(0xFF2E7D32) else Color(0xFFD32F2F), fontSize = 18.sp)
            }
        },
        confirmButton = {
            Button(
                enabled = !isCheckingCard && (jenisPasien == "Umum" || nomorKartu.trim().isNotEmpty()),
                onClick = {
                    if (jenisPasien == "BPJS") {
                        isCheckingCard = true
                        scope.launch {
                            try {
                                val response = ApiClient.apiService.cekValidasiBpjs(mapOf("nomor_kartu" to nomorKartu.trim()))
                                if (response.isSuccessful && response.body()?.status == true) {
                                    Toast.makeText(context, response.body()?.message ?: "Validasi Berhasil", Toast.LENGTH_SHORT).show()
                                    onConfirm(item.idPendaftaran, grandTotal.toDouble(), jenisPasien, nomorKartu.trim())
                                } else {
                                    Toast.makeText(context, response.body()?.message ?: "Kartu Tidak Valid!", Toast.LENGTH_LONG).show()
                                }
                            } catch (e: Exception) {
                                Toast.makeText(context, "Koneksi Gagal: ${e.message}", Toast.LENGTH_SHORT).show()
                            } finally {
                                isCheckingCard = false
                            }
                        }
                    } else {
                        onConfirm(item.idPendaftaran, grandTotal.toDouble(), jenisPasien, null)
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = if(jenisPasien == "BPJS") Color(0xFF1B5E20) else Color(0xFF4CAF50))
            ) {
                if (isCheckingCard) {
                    CircularProgressIndicator(modifier = Modifier.size(20.dp), color = Color.White, strokeWidth = 2.dp)
                } else {
                    Text(if (jenisPasien == "BPJS") "VERIFIKASI & PROSES" else "TERIMA LUNAS")
                }
            }
        },
        dismissButton = { TextButton(onClick = onDismiss, enabled = !isCheckingCard) { Text("Batal") } }
    )
}

// ======================================================================
// [BARU] HALAMAN ASURANSI
// ======================================================================

@Composable
fun RiwayatTransaksiScreen(refreshTrigger: Int) {
    var riwayatList by remember { mutableStateOf<List<Pembayaran>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }
    val context = LocalContext.current

    var day by remember { mutableStateOf("") }
    var month by remember { mutableStateOf("") }
    var year by remember { mutableStateOf("") }

    val calendar = Calendar.getInstance()
    val datePickerDialog = DatePickerDialog(
        context,
        { _, y, m, d ->
            year = y.toString()
            month = String.format("%02d", m + 1)
            day = String.format("%02d", d)
        },
        calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH)
    )

    LaunchedEffect(refreshTrigger) {
        isLoading = true
        try {
            val response = ApiClient.apiService.getRiwayatPembayaran()
            riwayatList = if (response.isSuccessful && response.body()?.status == true) response.body()?.data ?: emptyList() else emptyList()
        } catch (e: Exception) { Toast.makeText(context, "Error: ${e.message}", Toast.LENGTH_SHORT).show() }
        finally { isLoading = false }
    }

    val filteredList = riwayatList.filter {
        val parts = it.tanggal_bayar?.split("-")
        if (parts?.size == 3) {
            val matchYear = year.isEmpty() || parts[0].contains(year)
            val matchMonth = month.isEmpty() || parts[1].contains(month)
            val matchDay = day.isEmpty() || parts[2].contains(day)
            matchYear && matchMonth && matchDay
        } else true
    }

    val totalPendapatan = filteredList.sumOf { it.total_tagihan }
    val formatter = java.text.NumberFormat.getNumberInstance(java.util.Locale("id", "ID"))

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        // FILTER TANGGAL
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(value = day, onValueChange = { if (it.length <= 2) day = it }, label = { Text("DD") }, modifier = Modifier.weight(1f), singleLine = true)
            OutlinedTextField(value = month, onValueChange = { if (it.length <= 2) month = it }, label = { Text("MM") }, modifier = Modifier.weight(1f), singleLine = true)
            OutlinedTextField(value = year, onValueChange = { if (it.length <= 4) year = it }, label = { Text("YYYY") }, modifier = Modifier.weight(1.5f), singleLine = true)
            IconButton(onClick = { datePickerDialog.show() }) { Icon(Icons.Default.DateRange, "Pilih Tanggal", tint = MaterialTheme.colorScheme.primary) }
        }

        Spacer(Modifier.height(16.dp))
        Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)) {
            Column(Modifier.padding(16.dp)) {
                Text("Total Pendapatan Terfilter", fontSize = 12.sp)
                Text("Rp ${formatter.format(totalPendapatan)}", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
            }
        }
        Spacer(Modifier.height(16.dp))

        if (isLoading) Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
        else if (filteredList.isEmpty()) Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("Belum ada riwayat.", color = Color.Gray) }
        else {
            LazyColumn(Modifier.fillMaxSize()) {
                items(filteredList) { item ->
                    Card(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
                        elevation = CardDefaults.cardElevation(2.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFF1F8E9))
                    ) {
                        Column(Modifier.padding(16.dp)) {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(item.nama_pasien ?: "Pasien", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                Text(item.status_bayar, color = Color(0xFF2E7D32), fontWeight = FontWeight.ExtraBold)
                            }
                            HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = Color.LightGray)
                            Text("Tanggal: ${item.tanggal_bayar ?: "-"}", fontSize = 14.sp)
                            Text("Rp ${formatter.format(item.total_tagihan)}", fontWeight = FontWeight.Bold, color = Color(0xFFD32F2F))
                        }
                    }
                }
            }
        }
    }
}

// ======================================================================
// OBAT (DGN PENCARIAN & KATEGORI TAB)
// ======================================================================
@Composable
fun MedicineScreen(refreshTrigger: Int) {
    var medicines by remember { mutableStateOf<List<Obat>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }
    var showAddDialog by remember { mutableStateOf(false) }
    var selectedObat by remember { mutableStateOf<Obat?>(null) }

    // Pencarian dan Kategori
    var searchQuery by remember { mutableStateOf("") }
    var selectedKategori by remember { mutableStateOf("Semua") }
    val kategoriOptions = listOf("Semua", "Tablet", "Kapsul", "Sirup", "Salep", "Pcs")

    val scope = rememberCoroutineScope()
    val context = LocalContext.current

    val fetchData = suspend {
        isLoading = true
        try {
            val response = ApiClient.apiService.getObat()
            medicines = if (response.isSuccessful) response.body()?.data ?: emptyList() else emptyList()
        } catch (e: Exception) {} finally { isLoading = false }
    }

    LaunchedEffect(refreshTrigger) { fetchData() }

    // Logic Sortir & Filter Obat
    val filteredMedicines = medicines.filter {
        (selectedKategori == "Semua" || it.satuan.equals(selectedKategori, ignoreCase = true)) &&
                (searchQuery.isEmpty() || it.nama_obat.contains(searchQuery, ignoreCase = true))
    }

    Column(modifier = Modifier.fillMaxSize()) {
        // Search & Filter
        OutlinedTextField(
            value = searchQuery, onValueChange = { searchQuery = it },
            modifier = Modifier.fillMaxWidth().padding(16.dp),
            placeholder = { Text("Cari Nama Obat...") },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Cari") },
            singleLine = true
        )
        ScrollableTabRow(
            selectedTabIndex = kategoriOptions.indexOf(selectedKategori),
            edgePadding = 16.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            kategoriOptions.forEach { kategori ->
                Tab(
                    selected = selectedKategori == kategori,
                    onClick = { selectedKategori = kategori },
                    text = { Text(kategori) }
                )
            }
        }

        Box(modifier = Modifier.fillMaxSize().weight(1f)) {
            if (isLoading) Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
            else if (filteredMedicines.isEmpty()) Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("Obat tidak ditemukan.") }
            else {
                LazyColumn(Modifier.fillMaxSize().padding(16.dp)) {
                    items(filteredMedicines) { item ->
                        Card(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp).clickable { selectedObat = item }) {
                            Row(Modifier.padding(16.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text(item.nama_obat, fontWeight = FontWeight.Bold)
                                    Text("Rp ${item.harga_jual} / ${item.satuan}", color = Color.Gray, fontSize = 12.sp)
                                }
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    IconButton(onClick = { scope.launch { try { ApiClient.apiService.updateStokObat(item.id_obat, -1); fetchData() } catch (_: Exception) {} } }) { Icon(Icons.Default.Remove, "Kurangi") }
                                    Box(modifier = Modifier.size(40.dp).clip(CircleShape).background(MaterialTheme.colorScheme.secondaryContainer), contentAlignment = Alignment.Center) {
                                        Text(text = item.stok.toString(), fontWeight = FontWeight.Bold)
                                    }
                                    IconButton(onClick = { scope.launch { try { ApiClient.apiService.updateStokObat(item.id_obat, 1); fetchData() } catch (_: Exception) {} } }) { Icon(Icons.Default.Add, "Tambah") }
                                }
                            }
                        }
                    }
                }
            }

            FloatingActionButton(
                onClick = { showAddDialog = true },
                modifier = Modifier.align(Alignment.BottomEnd).padding(16.dp),
                containerColor = MaterialTheme.colorScheme.primary
            ) { Icon(Icons.Default.Add, "Tambah", tint = Color.White) }
        }
    }

    if (showAddDialog) ObatFormDialog("Tambah Obat", null, { showAddDialog = false }, { n, s, h, st -> scope.launch { ApiClient.apiService.addObat(n, s, h.toDouble(), st.toInt()); fetchData(); showAddDialog = false }})
    if (selectedObat != null) ObatFormDialog("Edit Obat", selectedObat, { selectedObat = null }, { n, s, h, st -> scope.launch { ApiClient.apiService.editObat(selectedObat!!.id_obat, n, s, h.toDouble(), st.toInt()); fetchData(); selectedObat = null }}, { scope.launch { ApiClient.apiService.deleteObat(selectedObat!!.id_obat); fetchData(); selectedObat = null }})
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ObatFormDialog(title: String, initialObat: Obat? = null, onDismiss: () -> Unit, onConfirm: (String, String, String, String) -> Unit, onDelete: (() -> Unit)? = null) {
    var nama by remember { mutableStateOf(initialObat?.nama_obat ?: "") }
    var satuan by remember { mutableStateOf(initialObat?.satuan ?: "Tablet") }
    var harga by remember { mutableStateOf(initialObat?.harga_jual?.toString() ?: "") }
    var stok by remember { mutableStateOf(initialObat?.stok?.toString() ?: "") }
    val satuanOptions = listOf("Tablet", "Kapsul", "Sirup", "Salep", "Pcs")

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text(title); if (onDelete != null) IconButton(onClick = onDelete) { Icon(Icons.Default.Delete, "Hapus", tint = MaterialTheme.colorScheme.error) } } },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = nama, onValueChange = { nama = it }, label = { Text("Nama Obat") }, modifier = Modifier.fillMaxWidth())
                Text("Satuan", style = MaterialTheme.typography.labelMedium)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    satuanOptions.forEach { option -> FilterChip(selected = satuan == option, onClick = { satuan = option }, label = { Text(option, fontSize = 10.sp) }) }
                }
                OutlinedTextField(value = harga, onValueChange = { harga = it }, label = { Text("Harga Jual") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = stok, onValueChange = { stok = it }, label = { Text("Stok") }, modifier = Modifier.fillMaxWidth())
            }
        },
        confirmButton = { Button(onClick = { if(nama.isNotEmpty() && harga.isNotEmpty()) onConfirm(nama, satuan, harga, stok) }) { Text("Simpan") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Batal") } }
    )
}

// ======================================================================
// ANTREAN (DGN FILTER DOKTER & KELOMPOK TANGGAL)
// ======================================================================
@Composable
fun QueueScreen(refreshTrigger: Int) {
    var selectedSubTab by remember { mutableIntStateOf(0) }
    Column(modifier = Modifier.fillMaxSize()) {
        TabRow(
            selectedTabIndex = selectedSubTab,
            containerColor = MaterialTheme.colorScheme.primaryContainer,
            contentColor = MaterialTheme.colorScheme.onPrimaryContainer
        ) {
            Tab(selected = selectedSubTab == 0, onClick = { selectedSubTab = 0 }, text = { Text("Antrean Aktif", fontWeight = FontWeight.Bold) })
            Tab(selected = selectedSubTab == 1, onClick = { selectedSubTab = 1 }, text = { Text("Riwayat Batal", fontWeight = FontWeight.Bold) })
        }
        Box(modifier = Modifier.fillMaxSize().weight(1f)) {
            if (selectedSubTab == 0) AntreanAdminAktif(refreshTrigger)
            else RiwayatBatalAdmin(refreshTrigger)
        }
    }
}

@Composable
fun AntreanAdminAktif(refreshTrigger: Int) {
    var queues by remember { mutableStateOf<List<AntreanItem>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }
    var selectedAntrean by remember { mutableStateOf<AntreanItem?>(null) }

    var selectedSpesialis by remember { mutableStateOf("Semua Spesialis") }
    var selectedDokter by remember { mutableStateOf("Semua Dokter") }

    val scope = rememberCoroutineScope()
    val context = LocalContext.current

    val fetchData = suspend {
        isLoading = true
        try {
            val response = ApiClient.apiService.getAntreanAdmin()
            queues = if (response.isSuccessful) response.body()?.data ?: emptyList() else emptyList()
        } catch (e: Exception) {} finally { isLoading = false }
    }

    LaunchedEffect(refreshTrigger) { fetchData() }

    // Hanya ambil yang Aktif (bukan Selesai/Batal)
    val antreanAktif = queues.filter { !it.status.equals("Selesai", true) && !it.status.equals("Batal", true) }

    // List Spesialis & Dokter dinamis
    val listSpesialis = listOf("Semua Spesialis") + antreanAktif.mapNotNull { it.spesialisasi }.distinct()
    val listDokter = listOf("Semua Dokter") + antreanAktif.filter { selectedSpesialis == "Semua Spesialis" || it.spesialisasi == selectedSpesialis }.mapNotNull { it.namaDokter }.distinct()

    val filteredQueues = antreanAktif.filter {
        (selectedSpesialis == "Semua Spesialis" || it.spesialisasi == selectedSpesialis) &&
                (selectedDokter == "Semua Dokter" || it.namaDokter == selectedDokter)
    }

    // Grouping by Tanggal Kunjungan
    val groupedQueues = filteredQueues.groupBy { it.tanggalKunjungan ?: "Tanggal Tidak Diketahui" }

    Column(modifier = Modifier.fillMaxSize()) {
        // TOP BAR FILTER DOKTER
        ScrollableTabRow(selectedTabIndex = listSpesialis.indexOf(selectedSpesialis).takeIf { it >= 0 } ?: 0, edgePadding = 16.dp, modifier = Modifier.fillMaxWidth()) {
            listSpesialis.forEach { sp -> Tab(selected = selectedSpesialis == sp, onClick = { selectedSpesialis = sp; selectedDokter = "Semua Dokter" }, text = { Text(sp) }) }
        }
        if (selectedSpesialis != "Semua Spesialis") {
            ScrollableTabRow(selectedTabIndex = listDokter.indexOf(selectedDokter).takeIf { it >= 0 } ?: 0, edgePadding = 16.dp, modifier = Modifier.fillMaxWidth()) {
                listDokter.forEach { d -> Tab(selected = selectedDokter == d, onClick = { selectedDokter = d }, text = { Text(d, fontSize = 12.sp) }) }
            }
        }

        if (isLoading) Box(Modifier.fillMaxSize().weight(1f), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
        else if (filteredQueues.isEmpty()) Box(Modifier.fillMaxSize().weight(1f), contentAlignment = Alignment.Center) { Text("Tidak ada antrean.") }
        else {
            LazyColumn(Modifier.fillMaxSize().weight(1f).padding(16.dp)) {
                groupedQueues.forEach { (tanggal, pasienList) ->
                    item {
                        Text(text = "TANGGAL: $tanggal", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(vertical = 8.dp))
                    }
                    items(pasienList) { item ->
                        Card(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp).clickable { selectedAntrean = item }) {
                            Row(Modifier.padding(16.dp).fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(end = 16.dp)) {
                                    Text("NO", style = MaterialTheme.typography.labelSmall)
                                    Text(item.noAntrean.toString(), style = MaterialTheme.typography.displaySmall, color = MaterialTheme.colorScheme.primary)
                                }
                                Column(Modifier.weight(1f)) {
                                    Text(item.namaPasien, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge)
                                    Text("Dokter: ${item.namaDokter ?: "Umum"} (${item.spesialisasi ?: "-"})", color = MaterialTheme.colorScheme.secondary, fontSize = 12.sp)
                                    Text("Jam: ${item.jamKunjungan ?: "--:--"}", style = MaterialTheme.typography.bodySmall)
                                    Spacer(Modifier.height(4.dp))
                                    val statusColor = when(item.status.lowercase()) { "menunggu" -> Color(0xFFFF9800); "diperiksa" -> Color(0xFF2196F3); else -> Color.Gray }
                                    Surface(color = statusColor, shape = CircleShape) { Text(item.status.uppercase(), modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp), style = MaterialTheme.typography.labelMedium, color = Color.White) }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (selectedAntrean != null) {
        UpdateStatusDialog(
            currentStatus = selectedAntrean!!.status,
            onDismiss = { selectedAntrean = null },
            onConfirm = { newStatus ->
                scope.launch {
                    try {
                        val resp = ApiClient.apiService.updateStatusAntrean(selectedAntrean!!.idPendaftaran, newStatus)
                        if (resp.isSuccessful) { Toast.makeText(context, "Status Diperbarui", Toast.LENGTH_SHORT).show(); fetchData(); selectedAntrean = null }
                    } catch (e: Exception) { Toast.makeText(context, "Gagal: ${e.message}", Toast.LENGTH_SHORT).show() }
                }
            }
        )
    }
}

@Composable
fun RiwayatBatalAdmin(refreshTrigger: Int) {
    var queues by remember { mutableStateOf<List<AntreanItem>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }
    val context = LocalContext.current
    var day by remember { mutableStateOf("") }
    var month by remember { mutableStateOf("") }
    var year by remember { mutableStateOf("") }

    val calendar = Calendar.getInstance()
    val datePickerDialog = DatePickerDialog(context, { _, y, m, d -> year = y.toString(); month = String.format("%02d", m + 1); day = String.format("%02d", d) }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH))

    LaunchedEffect(refreshTrigger) {
        isLoading = true
        try {
            val response = ApiClient.apiService.getAntreanAdmin()
            queues = if (response.isSuccessful) response.body()?.data ?: emptyList() else emptyList()
        } catch (e: Exception) {} finally { isLoading = false }
    }

    val riwayatBatal = queues.filter { it.status.equals("Batal", true) }
    val filteredList = riwayatBatal.filter {
        val parts = it.tanggalKunjungan?.split("-")
        if (parts?.size == 3) {
            val matchYear = year.isEmpty() || parts[0].contains(year)
            val matchMonth = month.isEmpty() || parts[1].contains(month)
            val matchDay = day.isEmpty() || parts[2].contains(day)
            matchYear && matchMonth && matchDay
        } else true
    }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(value = day, onValueChange = { if (it.length <= 2) day = it }, label = { Text("DD") }, modifier = Modifier.weight(1f), singleLine = true)
            OutlinedTextField(value = month, onValueChange = { if (it.length <= 2) month = it }, label = { Text("MM") }, modifier = Modifier.weight(1f), singleLine = true)
            OutlinedTextField(value = year, onValueChange = { if (it.length <= 4) year = it }, label = { Text("YYYY") }, modifier = Modifier.weight(1.5f), singleLine = true)
            IconButton(onClick = { datePickerDialog.show() }) { Icon(Icons.Default.DateRange, "Pilih Tanggal", tint = MaterialTheme.colorScheme.primary) }
        }
        Spacer(Modifier.height(16.dp))

        if (isLoading) Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
        else if (filteredList.isEmpty()) Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("Tidak ada antrean batal.", color = Color.Gray) }
        else {
            LazyColumn(Modifier.fillMaxSize()) {
                items(filteredList) { item ->
                    Card(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFFFFEBEE))) {
                        Column(Modifier.padding(16.dp)) {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(item.namaPasien, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                Text("BATAL", color = Color.Red, fontWeight = FontWeight.ExtraBold)
                            }
                            HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))
                            Text("Tanggal Batal: ${item.tanggalKunjungan ?: "-"}", fontSize = 14.sp)
                            Text("Dokter: ${item.namaDokter}", fontSize = 14.sp)
                        }
                    }
                }
            }
        }
    }
}

// ======================================================================
// KELOLA USER (DOKTER & PASIEN) DGN FILTER SPESIALIS
// ======================================================================
// ======================================================================
// KELOLA USER (DOKTER & PASIEN) DGN FILTER SPESIALIS & DETAIL POP-UP
// ======================================================================
@Composable
fun UserScreen(refreshTrigger: Int) {
    var users by remember { mutableStateOf<List<UserProfile>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }
    var selectedTabRole by remember { mutableIntStateOf(0) } // 0 = Pasien, 1 = Dokter
    var selectedSpesialis by remember { mutableStateOf("Semua Spesialis") }

    // [BARU] State untuk menyimpan user yang sedang diklik agar pop-up muncul
    var selectedUser by remember { mutableStateOf<UserProfile?>(null) }

    val context = LocalContext.current

    LaunchedEffect(refreshTrigger) {
        isLoading = true
        try {
            val response = ApiClient.apiService.getUsersAdmin()
            users = if (response.isSuccessful) response.body()?.data ?: emptyList() else emptyList()
        } catch (e: Exception) { Toast.makeText(context, "Error: ${e.message}", Toast.LENGTH_SHORT).show() }
        finally { isLoading = false }
    }

    val pasienList = users.filter { it.role.equals("pasien", true) }
    val dokterList = users.filter { it.role.equals("dokter", true) }

    val listSpesialis = listOf("Semua Spesialis") + dokterList.mapNotNull { it.spesialisasi }.distinct()
    val filteredDokterList = dokterList.filter { selectedSpesialis == "Semua Spesialis" || it.spesialisasi == selectedSpesialis }

    Column(Modifier.fillMaxSize()) {
        TabRow(selectedTabIndex = selectedTabRole, containerColor = MaterialTheme.colorScheme.primaryContainer) {
            Tab(selected = selectedTabRole == 0, onClick = { selectedTabRole = 0 }, text = { Text("Pasien", fontWeight = FontWeight.Bold) })
            Tab(selected = selectedTabRole == 1, onClick = { selectedTabRole = 1 }, text = { Text("Dokter", fontWeight = FontWeight.Bold) })
        }

        if (selectedTabRole == 1) {
            ScrollableTabRow(selectedTabIndex = listSpesialis.indexOf(selectedSpesialis).takeIf { it >= 0 } ?: 0, edgePadding = 16.dp) {
                listSpesialis.forEach { sp -> Tab(selected = selectedSpesialis == sp, onClick = { selectedSpesialis = sp }, text = { Text(sp) }) }
            }
        }

        Box(Modifier.fillMaxSize().weight(1f)) {
            if (isLoading) Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
            else {
                val activeList = if (selectedTabRole == 0) pasienList else filteredDokterList
                if (activeList.isEmpty()) Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("Data tidak ditemukan.") }
                else {
                    LazyColumn(Modifier.fillMaxSize().padding(16.dp)) {
                        items(activeList) { user ->
                            // [BARU] Tambahkan .clickable agar kartu bisa ditekan
                            Card(
                                modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp).clickable { selectedUser = user },
                                colors = CardDefaults.cardColors(containerColor = Color.White),
                                elevation = CardDefaults.cardElevation(2.dp)
                            ) {
                                Column(Modifier.padding(16.dp)) {
                                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                        Text(user.nama_lengkap ?: "Tanpa Nama", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = MaterialTheme.colorScheme.primary)
                                        Text("ID: ${user.id_user}", fontSize = 12.sp, color = Color.Gray)
                                    }
                                    Spacer(Modifier.height(8.dp))
                                    Text("Email: ${user.email}", fontSize = 14.sp)
                                    if (user.role.equals("dokter", true)) {
                                        Spacer(Modifier.height(4.dp))
                                        Surface(color = MaterialTheme.colorScheme.secondaryContainer, shape = CircleShape) { Text(" Spesialis: ${user.spesialisasi ?: "Umum"} ", modifier = Modifier.padding(4.dp), fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                                    } else {
                                        // Instruksi kecil agar admin tahu kartu ini bisa diklik
                                        Text("Ketuk untuk melihat NIK & Detail", fontSize = 12.sp, color = MaterialTheme.colorScheme.secondary, modifier = Modifier.padding(top = 8.dp))
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // ==========================================================
    // [BARU] POP-UP DIALOG DETAIL USER
    // ==========================================================
    if (selectedUser != null) {
        AlertDialog(
            onDismissRequest = { selectedUser = null },
            title = { Text("Detail Lengkap", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    Text("Nama: ${selectedUser!!.nama_lengkap ?: "-"}")
                    Text("Email: ${selectedUser!!.email}")
                    Text("No. Telepon: ${selectedUser!!.nomor_telepon ?: "-"}")
                    Text("Jenis Kelamin: ${selectedUser!!.jenis_kelamin ?: "-"}")

                    // Khusus untuk Pasien, tampilkan NIK, TTL, dan Alamat
                    // Khusus untuk Pasien, tampilkan NIK, TTL, Alamat, Golongan Darah & Alergi Obat
                    if (selectedUser!!.role.equals("pasien", true)) {
                        HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))
                        Text("NIK: ${selectedUser!!.nik ?: "-"}", fontWeight = FontWeight.SemiBold)
                        Text("Tanggal Lahir: ${selectedUser!!.tanggal_lahir ?: "-"}")
                        Text("Alamat: ${selectedUser!!.alamat ?: "-"}")

                        // [BARU] Tambahan Info Medis
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("Gol. Darah: ${selectedUser!!.golongan_darah ?: "-"}", color = MaterialTheme.colorScheme.error)
                        Text("Alergi Obat: ${selectedUser!!.alergi_obat ?: "-"}", color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.Medium)
                    }
                }
            },
            confirmButton = {
                Button(onClick = { selectedUser = null }) { Text("TUTUP") }
            }
        )
    }
}

// ======================================================================
// LAPORAN PENDAPATAN & STATISTIK BULANAN
// ======================================================================
@Composable
fun ReportScreen(refreshTrigger: Int) {
    var laporanList by remember { mutableStateOf<List<LaporanBulanan>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }
    val context = LocalContext.current

    LaunchedEffect(refreshTrigger) {
        isLoading = true
        try {
            val response = ApiClient.apiService.getLaporanAdmin()
            laporanList = if (response.isSuccessful) response.body()?.data ?: emptyList() else emptyList()
        } catch (e: Exception) { Toast.makeText(context, "Error: ${e.message}", Toast.LENGTH_SHORT).show() }
        finally { isLoading = false }
    }

    val formatter = java.text.NumberFormat.getNumberInstance(java.util.Locale("id", "ID"))

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        // [BARU] Header dengan Tombol Cetak
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Laporan Bulanan Klinik", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                Text("Rangkuman statistik pendapatan & pasien", fontSize = 14.sp, color = Color.Gray)
            }
            Button(onClick = { cetakLaporanPdf(context, laporanList) }) {
                Icon(Icons.Default.Print, contentDescription = "Cetak")
                Spacer(Modifier.width(8.dp))
                Text("Cetak")
            }
        }
        Spacer(Modifier.height(16.dp))

        if (isLoading) Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
        else if (laporanList.isEmpty()) Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("Belum ada data laporan yang tercatat.", color = Color.Gray) }
        else {
            LazyColumn(Modifier.fillMaxSize()) {
                items(laporanList) { laporan ->
                    Card(modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant), elevation = CardDefaults.cardElevation(4.dp)) {
                        Column(Modifier.padding(16.dp)) {
                            Text("Bulan: ${laporan.bulan} ${laporan.tahun}", fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
                            HorizontalDivider(Modifier.padding(vertical = 8.dp))

                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Pasien Selesai/Diperiksa:", fontSize = 14.sp)
                                Text("${laporan.total_pasien_selesai} Orang", fontWeight = FontWeight.Bold, color = Color(0xFF2E7D32))
                            }
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                Text("Pasien Batal:", fontSize = 14.sp)
                                Text("${laporan.total_pasien_batal} Orang", fontWeight = FontWeight.Bold, color = Color.Red)
                            }
                            Spacer(Modifier.height(12.dp))

                            Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
                                Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                    Text("Pendapatan Bersih:", fontWeight = FontWeight.Bold)
                                    Text("Rp ${formatter.format(laporan.total_pendapatan)}", fontWeight = FontWeight.ExtraBold, fontSize = 18.sp, color = Color(0xFFD32F2F))
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun UpdateStatusDialog(currentStatus: String, onDismiss: () -> Unit, onConfirm: (String) -> Unit) {
    // ADMIN HANYA BISA MENGUBAH JADI MENUNGGU, DIPERIKSA, DAN BATAL
    val options = listOf("MENUNGGU", "DIPERIKSA", "BATAL")

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Ubah Status Antrean") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                options.forEach { status ->
                    Row(Modifier.fillMaxWidth().clickable { onConfirm(status) }.padding(vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(selected = (status == currentStatus.uppercase()), onClick = { onConfirm(status) })
                        Text(status, modifier = Modifier.padding(start = 8.dp))
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Batal") } },
        dismissButton = {}
    )
}

// ======================================================================
// FUNGSI UNTUK MENCETAK LAPORAN KE PDF
// ======================================================================
fun cetakLaporanPdf(context: android.content.Context, laporanList: List<LaporanBulanan>) {
    if (laporanList.isEmpty()) {
        Toast.makeText(context, "Tidak ada data untuk dicetak", Toast.LENGTH_SHORT).show()
        return
    }

    val webView = WebView(context)
    val htmlContent = StringBuilder()
    val formatter = java.text.NumberFormat.getNumberInstance(java.util.Locale("id", "ID"))

    // Desain Tabel CSS untuk PDF
    htmlContent.append("<html><head><style>")
    htmlContent.append("table { width: 100%; border-collapse: collapse; margin-top: 20px; }")
    htmlContent.append("th, td { border: 1px solid black; padding: 10px; text-align: left; }")
    htmlContent.append("th { background-color: #4CAF50; color: white; }")
    htmlContent.append("</style></head><body>")

    htmlContent.append("<h2 style='text-align:center;'>LAPORAN PENDAPATAN KLINIK UMUM</h2>")
    htmlContent.append("<table>")
    htmlContent.append("<tr><th>Bulan & Tahun</th><th>Pasien Selesai</th><th>Pasien Batal</th><th>Total Pendapatan</th></tr>")

    var grandTotal = 0.0
    for (item in laporanList) {
        htmlContent.append("<tr>")
        htmlContent.append("<td>${item.bulan} ${item.tahun}</td>")
        htmlContent.append("<td>${item.total_pasien_selesai} Orang</td>")
        htmlContent.append("<td>${item.total_pasien_batal} Orang</td>")
        htmlContent.append("<td>Rp ${formatter.format(item.total_pendapatan)}</td>")
        htmlContent.append("</tr>")
        grandTotal += item.total_pendapatan
    }

    htmlContent.append("</table>")
    htmlContent.append("<h3 style='text-align:right; margin-top: 20px;'>Grand Total: Rp ${formatter.format(grandTotal)}</h3>")
    htmlContent.append("</body></html>")

    // Masukkan HTML ke WebView lalu jalankan PrintManager
    webView.loadDataWithBaseURL(null, htmlContent.toString(), "text/HTML", "UTF-8", null)
    val printManager = context.getSystemService(android.content.Context.PRINT_SERVICE) as PrintManager
    val printAdapter = webView.createPrintDocumentAdapter("Laporan_Klinik_Umum")
    printManager.print("Dokumen Laporan Klinik", printAdapter, PrintAttributes.Builder().build())
}

// ======================================================================
// HALAMAN ASURANSI
// ======================================================================
@Composable
fun AsuransiScreen(refreshTrigger: Int) {
    var asuransiList by remember { mutableStateOf<List<AsuransiPusat>>(emptyList()) }
    var mitraList by remember { mutableStateOf<List<String>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }
    val context = LocalContext.current

    LaunchedEffect(refreshTrigger) {
        isLoading = true
        try {
            // Memanggil 2 API sekaligus
            val responsePeserta = ApiClient.apiService.getAsuransi()
            val responseMitra = ApiClient.apiService.getMitraAsuransi()

            if (responsePeserta.isSuccessful) {
                asuransiList = responsePeserta.body()?.data ?: emptyList()
            }
            if (responseMitra.isSuccessful) {
                mitraList = responseMitra.body()?.data ?: emptyList()
            }
        } catch (e: Exception) {
            Toast.makeText(context, "Error: ${e.message}", Toast.LENGTH_SHORT).show()
        } finally {
            isLoading = false
        }
    }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Mitra Asuransi Terdaftar", fontSize = 16.sp, fontWeight = FontWeight.SemiBold, color = Color.Gray)
        Spacer(Modifier.height(8.dp))

        // Menampilkan asuransi apa saja yang ada secara Horizontal
        if (mitraList.isNotEmpty()) {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(mitraList) { mitra ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                        shape = CircleShape
                    ) {
                        Text(
                            text = mitra,
                            modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                    }
                }
            }
        } else if (!isLoading) {
            Text("Belum ada asuransi yang terdaftar.", fontSize = 14.sp, fontStyle = androidx.compose.ui.text.font.FontStyle.Italic)
        }

        Spacer(Modifier.height(24.dp))
        HorizontalDivider()
        Spacer(Modifier.height(16.dp))

        Text("Daftar Kepesertaan Pasien", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
        Spacer(Modifier.height(16.dp))

        if (isLoading) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
        } else if (asuransiList.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("Data Asuransi Kosong") }
        } else {
            LazyColumn(Modifier.fillMaxSize()) {
                items(asuransiList) { item ->
                    Card(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                    ) {
                        Column(Modifier.padding(16.dp)) {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(item.nama_asuransi, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                                val statusColor = if (item.status_kepesertaan == "AKTIF") Color(0xFF2E7D32) else Color.Red
                                Text(item.status_kepesertaan, color = statusColor, fontWeight = FontWeight.Bold)
                            }
                            Spacer(Modifier.height(8.dp))
                            Text("NIK: ${item.nik_peserta}")
                            Text("No. Kartu: ${item.nomor_kartu}")
                        }
                    }
                }
            }
        }
    }
}