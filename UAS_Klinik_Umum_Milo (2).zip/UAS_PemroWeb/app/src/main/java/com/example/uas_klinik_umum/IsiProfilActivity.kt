package com.example.uas_klinik_umum

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusDirection
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.key.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.uas_klinik_umum.network.ApiClient
import com.example.uas_klinik_umum.network.ProfilPasienRequest
import kotlinx.coroutines.launch
import java.util.Calendar

class IsiProfilActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val idUser = intent.getIntExtra("EXTRA_ID_USER", -1)

        setContent {
            MaterialTheme {
                IsiProfilScreen(idUser = idUser, onProfilSukses = {
                    Toast.makeText(this, "Profil Anda telah dikunci dan disimpan!", Toast.LENGTH_LONG).show()
                    val intent = Intent(this, LoginActivity::class.java)
                    intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                    startActivity(intent)
                    finish()
                })
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun IsiProfilScreen(idUser: Int, onProfilSukses: () -> Unit) {
    var namaLengkap by remember { mutableStateOf("") }
    var nik by remember { mutableStateOf("") }
    var tidakTahuNik by remember { mutableStateOf(false) }
    var jenisKelamin by remember { mutableStateOf("Laki-laki") }

    // Variabel Tanggal Terpisah
    var tanggalLahir by remember { mutableStateOf("") }
    var bulanLahir by remember { mutableStateOf("") }
    var tahunLahir by remember { mutableStateOf("") }

    var nomorTelepon by remember { mutableStateOf("") }
    var alamat by remember { mutableStateOf("") }
    var golonganDarah by remember { mutableStateOf("-") }

    // Variabel Alergi Obat
    var statusAlergi by remember { mutableStateOf("Tidak Ada") }
    var alergiObat by remember { mutableStateOf("") }

    var isDatePickerOpen by remember { mutableStateOf(false) }
    var isLoading by remember { mutableStateOf(false) }

    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val focusManager = LocalFocusManager.current
    val currentYear = Calendar.getInstance().get(Calendar.YEAR)

    LaunchedEffect(tidakTahuNik) {
        if (tidakTahuNik) nik = "0000000000000000" else if (nik == "0000000000000000") nik = ""
    }

    val handleSimpanProfil = {
        val finalNik = if (tidakTahuNik) "0000000000000000" else nik
        val tgl = tanggalLahir.padStart(2, '0')
        val bln = bulanLahir.padStart(2, '0')
        val finalTanggalLahir = "$tahunLahir-$bln-$tgl"
        val finalTelepon = "+62$nomorTelepon"
        val finalAlergi = if (statusAlergi == "Ada") alergiObat else "-"

        // ==========================================
        // VALIDASI KALENDER SUNGGUHAN (STRICT PARSING)
        // ==========================================
        var isDateValid = false
        if (tanggalLahir.isNotEmpty() && bulanLahir.isNotEmpty() && tahunLahir.length == 4) {
            try {
                // Memaksa sistem membaca tanggal kalender asli (misal: 31 Feb akan ditolak)
                val sdf = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.getDefault())
                sdf.isLenient = false
                sdf.parse(finalTanggalLahir)

                val yearInt = tahunLahir.toInt()
                // Pastikan tahun logis (misal antara 1900 hingga saat ini)
                if (yearInt in 1900..currentYear) {
                    isDateValid = true
                }
            } catch (e: Exception) {
                isDateValid = false
            }
        }

        if (!isDateValid) {
            Toast.makeText(context, "Tanggal lahir tidak valid / format kalender salah!", Toast.LENGTH_SHORT).show()
        } else if (namaLengkap.isNotEmpty() && finalNik.isNotEmpty() && nomorTelepon.isNotEmpty() && alamat.isNotEmpty()) {

            isLoading = true
            coroutineScope.launch {
                try {
                    val req = ProfilPasienRequest(
                        idUser = idUser,
                        nama = namaLengkap,
                        nik = finalNik,
                        jk = jenisKelamin,
                        tglLahir = finalTanggalLahir,
                        telp = finalTelepon,
                        alamat = alamat,
                        golDarah = golonganDarah,
                        alergi = finalAlergi
                    )

                    val response = ApiClient.apiService.simpanProfil(req)

                    if (response.isSuccessful && response.body()?.status == true) {
                        onProfilSukses()
                    } else {
                        Toast.makeText(context, response.body()?.message ?: "Gagal menyimpan", Toast.LENGTH_LONG).show()
                    }
                } catch (e: Exception) {
                    Toast.makeText(context, "Koneksi Bermasalah: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
                } finally {
                    isLoading = false
                }
            }
        } else {
            Toast.makeText(context, "Mohon lengkapi semua data wajib!", Toast.LENGTH_SHORT).show()
        }
    }

    val enterToSubmitModifier = Modifier.onPreviewKeyEvent { keyEvent ->
        if ((keyEvent.key == Key.Enter || keyEvent.key == Key.NumPadEnter) && keyEvent.type == KeyEventType.KeyUp) {
            focusManager.clearFocus()
            handleSimpanProfil()
            true
        } else {
            false
        }
    }

    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp).verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("LENGKAPI DATA PASIEN", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text("Isi data dengan benar sebelum menggunakan layanan klinik", fontSize = 12.sp, color = Color.Gray)
        Spacer(modifier = Modifier.height(24.dp))

        OutlinedTextField(
            value = namaLengkap,
            onValueChange = { namaLengkap = it },
            label = { Text("Nama Lengkap (Sesuai KTP) *") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth().then(enterToSubmitModifier),
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
            keyboardActions = KeyboardActions(onNext = { focusManager.moveFocus(FocusDirection.Down) })
        )
        Spacer(modifier = Modifier.height(16.dp))

        OutlinedTextField(
            value = nik,
            onValueChange = { if (!tidakTahuNik) nik = it.filter { char -> char.isDigit() } },
            label = { Text("NIK (16 Digit) *") },
            enabled = !tidakTahuNik,
            singleLine = true,
            modifier = Modifier.fillMaxWidth().then(enterToSubmitModifier),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Next),
            keyboardActions = KeyboardActions(onNext = { focusManager.moveFocus(FocusDirection.Down) })
        )
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth().padding(top = 4.dp)
        ) {
            Checkbox(checked = tidakTahuNik, onCheckedChange = { tidakTahuNik = it })
            Text("Saya tidak tahu NIK saya / Belum punya KTP", fontSize = 13.sp)
        }
        Spacer(modifier = Modifier.height(12.dp))

        Text("Jenis Kelamin *", modifier = Modifier.fillMaxWidth().wrapContentWidth(Alignment.Start), fontWeight = FontWeight.Medium)
        CustomDropdown(
            options = listOf("Laki-laki", "Perempuan"),
            selectedOption = jenisKelamin,
            onOptionSelected = { jenisKelamin = it }
        )
        Spacer(modifier = Modifier.height(16.dp))

        Text("Tanggal Lahir *", modifier = Modifier.fillMaxWidth().wrapContentWidth(Alignment.Start), fontWeight = FontWeight.Medium)
        Row(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = tanggalLahir,
                onValueChange = {
                    if (it.length <= 2) {
                        var filtered = it.filter { c -> c.isDigit() }
                        // AUTO-CORRECT TANGGAL
                        if (filtered.length == 2) {
                            val dayInt = filtered.toIntOrNull() ?: 0
                            if (dayInt > 31) filtered = "31"
                            if (dayInt == 0) filtered = "01"
                        }
                        tanggalLahir = filtered
                        if (tanggalLahir.length == 2) focusManager.moveFocus(FocusDirection.Right)
                    }
                },
                label = { Text("DD") },
                singleLine = true,
                modifier = Modifier.weight(1f).then(enterToSubmitModifier),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Next),
                keyboardActions = KeyboardActions(onNext = { focusManager.moveFocus(FocusDirection.Right) })
            )
            OutlinedTextField(
                value = bulanLahir,
                onValueChange = {
                    if (it.length <= 2) {
                        var filtered = it.filter { c -> c.isDigit() }
                        // AUTO-CORRECT BULAN
                        if (filtered.length == 2) {
                            val monthInt = filtered.toIntOrNull() ?: 0
                            if (monthInt > 12) filtered = "12"
                            if (monthInt == 0) filtered = "01"
                        }
                        bulanLahir = filtered
                        if (bulanLahir.length == 2) focusManager.moveFocus(FocusDirection.Right)
                    }
                },
                label = { Text("MM") },
                singleLine = true,
                modifier = Modifier.weight(1f).then(enterToSubmitModifier),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Next),
                keyboardActions = KeyboardActions(onNext = { focusManager.moveFocus(FocusDirection.Right) })
            )
            OutlinedTextField(
                value = tahunLahir,
                onValueChange = {
                    if (it.length <= 4) {
                        var filtered = it.filter { c -> c.isDigit() }
                        // AUTO-CORRECT TAHUN
                        if (filtered.length == 4) {
                            val yearInt = filtered.toIntOrNull() ?: 0
                            if (yearInt > currentYear) filtered = currentYear.toString()
                        }
                        tahunLahir = filtered
                        if (tahunLahir.length == 4) focusManager.moveFocus(FocusDirection.Down)
                    }
                },
                label = { Text("YYYY") },
                singleLine = true,
                modifier = Modifier.weight(1.5f).then(enterToSubmitModifier),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Next),
                keyboardActions = KeyboardActions(onNext = { focusManager.moveFocus(FocusDirection.Down) })
            )
            // Tombol popup kalender di pojok kanan
            IconButton(onClick = { isDatePickerOpen = true }) {
                Text("📅", fontSize = 24.sp)
            }
        }
        Spacer(modifier = Modifier.height(16.dp))

        OutlinedTextField(
            value = nomorTelepon,
            onValueChange = {
                val digits = it.filter { char -> char.isDigit() }
                val processed = if (digits.startsWith("0")) digits.drop(1) else digits
                if (processed.length <= 11) nomorTelepon = processed // Batasi maksimal 11 karakter
            },
            label = { Text("Nomor Whatsapp/HP *") },
            leadingIcon = { Text("+62", modifier = Modifier.padding(start = 12.dp, end = 4.dp), fontWeight = FontWeight.Bold) },
            singleLine = true,
            modifier = Modifier.fillMaxWidth().then(enterToSubmitModifier),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone, imeAction = ImeAction.Next),
            keyboardActions = KeyboardActions(onNext = { focusManager.moveFocus(FocusDirection.Down) })
        )
        Spacer(modifier = Modifier.height(16.dp))

        OutlinedTextField(
            value = alamat,
            onValueChange = { alamat = it },
            label = { Text("Alamat Tempat Tinggal *") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth().then(enterToSubmitModifier),
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
            keyboardActions = KeyboardActions(onDone = { focusManager.clearFocus() })
        )
        Spacer(modifier = Modifier.height(16.dp))

        Text("Golongan Darah", modifier = Modifier.fillMaxWidth().wrapContentWidth(Alignment.Start), fontWeight = FontWeight.Medium)
        CustomDropdown(
            options = listOf("-", "A", "B", "AB", "O"),
            selectedOption = golonganDarah,
            onOptionSelected = { golonganDarah = it }
        )
        Spacer(modifier = Modifier.height(16.dp))

        Text("Apakah Anda memiliki alergi obat?", modifier = Modifier.fillMaxWidth().wrapContentWidth(Alignment.Start), fontWeight = FontWeight.Medium)
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth()
        ) {
            RadioButton(selected = statusAlergi == "Tidak Ada", onClick = { statusAlergi = "Tidak Ada" })
            Text("Tidak Ada")
            Spacer(modifier = Modifier.width(16.dp))
            RadioButton(selected = statusAlergi == "Ada", onClick = { statusAlergi = "Ada" })
            Text("Ada")
        }

        if (statusAlergi == "Ada") {
            OutlinedTextField(
                value = alergiObat,
                onValueChange = { alergiObat = it },
                label = { Text("Sebutkan Obat (Misal: Paracetamol) *") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth().then(enterToSubmitModifier),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                keyboardActions = KeyboardActions(onDone = { focusManager.clearFocus(); handleSimpanProfil() })
            )
        }

        Spacer(modifier = Modifier.height(32.dp))

        Button(
            onClick = { handleSimpanProfil() },
            modifier = Modifier.fillMaxWidth(),
            enabled = !isLoading
        ) {
            if (isLoading) {
                CircularProgressIndicator(modifier = Modifier.size(24.dp), color = MaterialTheme.colorScheme.onPrimary)
            } else {
                Text("SIMPAN PROFIL", fontWeight = FontWeight.Bold)
            }
        }
        Spacer(modifier = Modifier.height(32.dp))
        TextButton(
            onClick = {
                val intent = Intent(context, LoginActivity::class.java)
                intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                context.startActivity(intent)
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Kembali ke Login (Isi Nanti)", color = Color.Gray, fontWeight = FontWeight.SemiBold)
        }
        Spacer(modifier = Modifier.height(16.dp))
    }

    if (isDatePickerOpen) {
        val datePickerState = rememberDatePickerState()
        DatePickerDialog(
            onDismissRequest = { isDatePickerOpen = false },
            confirmButton = {
                TextButton(onClick = {
                    val selectedDate = datePickerState.selectedDateMillis
                    if (selectedDate != null) {
                        val cal = Calendar.getInstance().apply { timeInMillis = selectedDate }
                        // PERBAIKAN: Memecah hasil kalender ke dalam 3 kolom yang baru
                        tahunLahir = cal.get(Calendar.YEAR).toString()
                        bulanLahir = String.format("%02d", cal.get(Calendar.MONTH) + 1)
                        tanggalLahir = String.format("%02d", cal.get(Calendar.DAY_OF_MONTH))
                    }
                    isDatePickerOpen = false
                }) { Text("OK") }
            },
            dismissButton = {
                TextButton(onClick = { isDatePickerOpen = false }) { Text("BATAL") }
            }
        ) {
            DatePicker(state = datePickerState)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CustomDropdown(
    options: List<String>,
    selectedOption: String,
    onOptionSelected: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var expanded by remember { mutableStateOf(false) }

    ExposedDropdownMenuBox(
        expanded = expanded,
        onExpandedChange = { expanded = !expanded },
        modifier = modifier.fillMaxWidth()
    ) {
        OutlinedTextField(
            value = selectedOption,
            onValueChange = {},
            readOnly = true,
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
            modifier = Modifier.menuAnchor().fillMaxWidth()
        )
        ExposedDropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false }
        ) {
            options.forEach { option ->
                DropdownMenuItem(
                    text = { Text(option) },
                    onClick = {
                        onOptionSelected(option)
                        expanded = false
                    }
                )
            }
        }
    }
}