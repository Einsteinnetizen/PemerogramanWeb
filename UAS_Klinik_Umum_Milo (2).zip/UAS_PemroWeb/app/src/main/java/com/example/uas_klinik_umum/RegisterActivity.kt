package com.example.uas_klinik_umum

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.example.uas_klinik_umum.network.ApiClient
import com.example.uas_klinik_umum.network.RegisterAccountRequest
import kotlinx.coroutines.launch

class RegisterActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { RegisterScreen(onNavigateBack = { finish() }) } }
    }
}

@Composable
fun RegisterScreen(onNavigateBack: () -> Unit) {
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }
    var isLoading by remember { mutableStateOf(false) }

    val coroutineScope = rememberCoroutineScope()
    val context = LocalContext.current
    val focusManager = LocalFocusManager.current

    // VALIDASI LOGIC
    val isEmailValid = email.endsWith("@gmail.com") || email.endsWith("@klinik.com")
    val isPasswordValid = password.length >= 6
    val isFormComplete = isEmailValid && isPasswordValid && password == confirmPassword && email.isNotEmpty()

    fun handleRegister() {
        if (!isFormComplete) return
        isLoading = true
        coroutineScope.launch {
            try {
                val response = ApiClient.apiService.registerAkun(RegisterAccountRequest(email, password))
                if (response.isSuccessful && response.body()?.status == true) {
                    Toast.makeText(context, "Akun Dibuat! Silakan Login", Toast.LENGTH_LONG).show()
                    onNavigateBack()
                } else {
                    Toast.makeText(context, response.body()?.message ?: "Gagal Daftar", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                Toast.makeText(context, "Error: ${e.message}", Toast.LENGTH_SHORT).show()
            } finally { isLoading = false }
        }
    }

    Column(modifier = Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center) {
        Text("Daftar Akun Baru", style = MaterialTheme.typography.headlineMedium)
        Spacer(modifier = Modifier.height(8.dp))
        Text("Email wajib menggunakan @gmail.com atau @klinik.com", color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(modifier = Modifier.height(24.dp))

        OutlinedTextField(
            value = email,
            onValueChange = { email = it.lowercase() }, // Otomatis ubah ke huruf kecil
            label = { Text("Email") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
            isError = email.isNotEmpty() && !isEmailValid
        )

        Spacer(modifier = Modifier.height(16.dp))
        OutlinedTextField(
            value = password,
            onValueChange = { password = it },
            label = { Text("Password (Min 6 Karakter)") },
            singleLine = true,
            visualTransformation = PasswordVisualTransformation(),
            modifier = Modifier.fillMaxWidth(),
            isError = password.isNotEmpty() && !isPasswordValid,
            supportingText = { if (password.isNotEmpty() && !isPasswordValid) Text("Password kurang dari 6 karakter!", color = MaterialTheme.colorScheme.error) }
        )

        Spacer(modifier = Modifier.height(16.dp))
        OutlinedTextField(
            value = confirmPassword,
            onValueChange = { confirmPassword = it },
            label = { Text("Ulangi Password") },
            singleLine = true,
            visualTransformation = PasswordVisualTransformation(),
            modifier = Modifier.fillMaxWidth(),
            enabled = isPasswordValid, // Lumpuh jika password belum 6 karakter
            isError = confirmPassword.isNotEmpty() && password != confirmPassword,
            supportingText = { if (confirmPassword.isNotEmpty() && password != confirmPassword) Text("Password tidak sama!", color = MaterialTheme.colorScheme.error) }
        )

        Spacer(modifier = Modifier.height(24.dp))
        Button(
            onClick = { handleRegister() },
            modifier = Modifier.fillMaxWidth(),
            enabled = isFormComplete && !isLoading // Lumpuh jika belum sesuai ketentuan
        ) { Text(if (isLoading) "MEMPROSES..." else "LANJUTKAN") }

        Spacer(modifier = Modifier.height(16.dp))
        TextButton(onClick = onNavigateBack) { Text("Kembali ke Login") }
    }
}