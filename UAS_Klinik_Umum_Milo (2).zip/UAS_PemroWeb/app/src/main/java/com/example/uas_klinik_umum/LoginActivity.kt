package com.example.uas_klinik_umum

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.key.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.example.uas_klinik_umum.network.ApiClient
import com.example.uas_klinik_umum.network.LoginRequest
import com.example.uas_klinik_umum.utils.SessionManager
import kotlinx.coroutines.launch

class LoginActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val sessionManager = SessionManager(this)

        setContent {
            MaterialTheme {
                // Menerima 3 data dari hasil Login: Role, Status Profil, dan ID User
                LoginScreen(sessionManager, onLoginSuccess = { roleUser, isProfileComplete, idUser ->
                    routeToDashboard(roleUser, isProfileComplete, idUser)
                })
            }
        }
    }

    private fun routeToDashboard(role: String, isProfileComplete: Boolean, idUser: Int) {
        // Jika dia pasien tapi profil belum lengkap, belokkan ke IsiProfilActivity
        if (role.lowercase() == "pasien" && !isProfileComplete) {
            val intent = Intent(this, IsiProfilActivity::class.java).apply {
                putExtra("EXTRA_ID_USER", idUser)
            }
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            startActivity(intent)
            finish()
            return
        }

        // Jika profil sudah lengkap (atau jika Admin/Dokter), arahkan secara normal
        val intent = when (role.lowercase()) {
            "admin" -> Intent(this, AdminDashboardActivity::class.java)
            "dokter" -> Intent(this, DokterDashboardActivity::class.java)
            else -> Intent(this, PasienDashboardActivity::class.java)
        }
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        startActivity(intent)
        finish()
    }
}

@Composable
fun LoginScreen(sessionManager: SessionManager, onLoginSuccess: (String, Boolean, Int) -> Unit) {
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var isLoading by remember { mutableStateOf(false) }

    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val focusManager = LocalFocusManager.current
    val isEmailValid = email.endsWith("@gmail.com") || email.endsWith("@klinik.com")
    val isFormComplete = isEmailValid && password.isNotEmpty()

    val handleLogin = {
        if (email.trim().isNotEmpty() && password.isNotEmpty()) {
            isLoading = true
            coroutineScope.launch {
                try {
                    val request = LoginRequest(email.trim(), password)
                    val response = ApiClient.apiService.login(request)

                    if (response.isSuccessful) {
                        val body = response.body()
                        val userData = body?.data

                        if (body?.status == true && userData != null) {
                            // Baca nilai kelengkapan profil dari server (Default: true jika null)
                            val isComplete = body.is_profile_complete ?: true

                            // 🔴 PERBAIKAN: Gunakan saveSession yang baru.
                            // Kita bisa langsung percaya pada userData.nama karena PHP sudah memastikan isinya benar!
                            sessionManager.saveSession(
                                idUser = userData.id_user,
                                email = userData.email,
                                role = userData.role,
                                nama = userData.nama,
                                token = body.token
                            )

                            // (Opsional) Jika di SessionManager-mu masih ada fungsi saveProfileStatus,
                            // silakan hapus tanda komentar pada baris di bawah ini:
                            // sessionManager.saveProfileStatus(isComplete)

                            Toast.makeText(context, body.message, Toast.LENGTH_SHORT).show()

                            // Lemparkan datanya ke fungsi routeToDashboard di atas
                            onLoginSuccess(userData.role, isComplete, userData.id_user)
                        } else {
                            Toast.makeText(context, body?.message ?: "Login Gagal", Toast.LENGTH_LONG).show()
                        }
                    } else {
                        Toast.makeText(context, "Error Server: HTTP ${response.code()}", Toast.LENGTH_LONG).show()
                    }
                } catch (e: Exception) {
                    Toast.makeText(context, "Masalah Koneksi: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
                } finally {
                    isLoading = false
                }
            }
        } else {
            Toast.makeText(context, "Isi Email dan Password!", Toast.LENGTH_SHORT).show()
        }
    }

    val enterToSubmitModifier = Modifier.onPreviewKeyEvent { keyEvent ->
        if ((keyEvent.key == Key.Enter || keyEvent.key == Key.NumPadEnter) && keyEvent.type == KeyEventType.KeyUp) {
            focusManager.clearFocus()
            handleLogin()
            true
        } else {
            false
        }
    }

    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Login Klinikku", style = MaterialTheme.typography.headlineMedium)
        Spacer(modifier = Modifier.height(32.dp))

        OutlinedTextField(
            value = email,
            onValueChange = { email = it.lowercase() },
            label = { Text("Email") },
            isError = email.isNotEmpty() && !isEmailValid,
            singleLine = true,
            modifier = Modifier.fillMaxWidth().then(enterToSubmitModifier),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email, imeAction = ImeAction.Done),
            keyboardActions = KeyboardActions(onDone = { focusManager.clearFocus(); handleLogin() })
        )

        Spacer(modifier = Modifier.height(16.dp))

        OutlinedTextField(
            value = password,
            onValueChange = { password = it },
            label = { Text("Password") },
            singleLine = true,
            visualTransformation = PasswordVisualTransformation(),
            modifier = Modifier.fillMaxWidth().then(enterToSubmitModifier),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password, imeAction = ImeAction.Done),
            keyboardActions = KeyboardActions(onDone = { focusManager.clearFocus(); handleLogin() })
        )

        Spacer(modifier = Modifier.height(24.dp))

        Button(
            onClick = { handleLogin() },
            modifier = Modifier.fillMaxWidth(),
            enabled = isFormComplete && !isLoading
        ) {
            if (isLoading) CircularProgressIndicator(modifier = Modifier.size(24.dp)) else Text("MASUK")
        }

        Spacer(modifier = Modifier.height(16.dp))
        TextButton(onClick = { context.startActivity(Intent(context, ForgotPasswordActivity::class.java)) }) { Text("Lupa Password?") }
        TextButton(onClick = { context.startActivity(Intent(context, RegisterActivity::class.java)) }) { Text("Belum punya akun? Daftar Pasien Baru") }
    }
}