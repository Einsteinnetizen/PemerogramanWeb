package com.example.uas_klinik_umum

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// Data Dummy untuk Artikel Kesehatan Komponen LinkedList/List Foto
data class InfoPenyakit(val id: Int, val judul: String, val deskripsi: String, val ilustrasiIcon: ImageVector)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    namaPasien: String = "Pasien",
    onMenuDaftarClick: () -> Unit,
    onMenuTiketClick: () -> Unit
) {
    val DEFAULT_SPACING = 16
    val listArtikel = listOf(
        InfoPenyakit(1, "Cegah DBD", "Menjaga kebersihan lingkungan dengan 3M Plus untuk hindari nyamuk.", Icons.Default.Info),
        InfoPenyakit(2, "Gejala Influenza", "Kenali perbedaan flu biasa dengan infeksi virus musiman.", Icons.Default.Info),
        InfoPenyakit(3, "Hipertensi", "Tips mengontrol tekanan darah tinggi melalui pola makan sehat.", Icons.Default.Info)
    )

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("KlinikKu", fontWeight = FontWeight.Bold, color = Color.White) },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.primary)
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .padding(innerPadding)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(DEFAULT_SPACING.dp)
        ) {
            // Welcome Section
            Text(text = "Selamat Datang,", fontSize = 16.sp, color = Color.Gray)
            Text(text = namaPasien, fontSize = 24.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)

            Spacer(modifier = Modifier.height(24.dp))

            // Menu Layanan Utama Utama
            Text(text = "Layanan Klinik", fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                MenuUtamaItem(judul = "Daftar Berobat", icon = Icons.Default.DateRange, warna = Color(0xFFE3F2FD), onClick = onMenuDaftarClick)
                MenuUtamaItem(judul = "Tiket Aktif", icon = Icons.Default.Person, warna = Color(0xFFE8F5E9), onClick = onMenuTiketClick)
            }

            Spacer(modifier = Modifier.height(32.dp))

            // Carousel / List Artikel Info Penyakit (Implementasi Linkedlist/List Foto Berjejer Horizontal)
            Text(text = "Informasi & Edukasi Kesehatan", fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
            Spacer(modifier = Modifier.height(12.dp))

            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(listArtikel) { artikel ->
                    CardArtikel(artikel = artikel)
                }
            }
        }
    }
}

@Composable
fun MenuUtamaItem(judul: String, icon: ImageVector, warna: Color, onClick: () -> Unit) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.clickable { onClick() }
    ) {
        Box(
            modifier = Modifier
                .size(70.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(warna),
            contentAlignment = Alignment.Center
        ) {
            Icon(imageVector = icon, contentDescription = judul, modifier = Modifier.size(36.dp), tint = MaterialTheme.colorScheme.primary)
        }
        Spacer(modifier = Modifier.height(8.dp))
        Text(text = judul, fontSize = 14.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
fun CardArtikel(artikel: InfoPenyakit) {
    Card(
        modifier = Modifier.width(220.dp),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(110.dp)
                    .background(MaterialTheme.colorScheme.primaryContainer),
                contentAlignment = Alignment.Center
            ) {
                Icon(imageVector = artikel.ilustrasiIcon, contentDescription = null, modifier = Modifier.size(48.dp), tint = MaterialTheme.colorScheme.onPrimaryContainer)
            }
            Column(modifier = Modifier.padding(12.dp)) {
                Text(text = artikel.judul, fontWeight = FontWeight.Bold, fontSize = 16.sp, maxLines = 1)
                Spacer(modifier = Modifier.height(4.dp))
                Text(text = artikel.deskripsi, fontSize = 12.sp, color = Color.DarkGray, maxLines = 2)
            }
        }
    }
}