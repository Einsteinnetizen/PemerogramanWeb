package com.example.uas_klinik_umum.network

import com.google.gson.GsonBuilder
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

object ApiClient {
    private const val BASE_URL = "http://10.201.118.223/klinik_api/api/" // Ganti dengan IP Anda

    // 1. Buat Gson yang "Lenient" (Santai/Toleran terhadap format yang sedikit salah)
    private val gson = GsonBuilder()
        .setLenient()
        .create()

    // 2. Masukkan Gson tersebut ke dalam Retrofit
    val apiService: ApiService by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .addConverterFactory(GsonConverterFactory.create(gson)) // Gunakan gson yang di atas
            .build()
            .create(ApiService::class.java)
    }
}