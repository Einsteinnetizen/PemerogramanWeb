package com.example.uas_klinik_umum

import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.uas_klinik_umum.network.*
import com.example.uas_klinik_umum.utils.SessionManager
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PendaftaranScreen(
    sessionManager: SessionManager,
    onPendaftaranSukses: () -> Unit // Parameter tambahan untuk navigasi otomatis
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val focusManager = LocalFocusManager.current

    var dokterList by remember { mutableStateOf<List<Dokter>>(emptyList()) }
    var spesialisasiTerpilih by remember { mutableStateOf("") }
    var dokterTerpilih by remember { mutableStateOf<Dokter?>(null) }
    var hariTerpilih by remember { mutableStateOf("") }

    // State untuk memisahkan input jam dan menit secara bebas
    var inputJam by remember { mutableStateOf("") }
    var inputMenit by remember { mutableStateOf("") }

    var keluhan by remember { mutableStateOf("") }
    var isLoading by remember { mutableStateOf(false) }


    // Dropdown States
    var spesialisasiDropdownExpanded by remember { mutableStateOf(false) }
    var dokterDropdownExpanded by remember { mutableStateOf(false) }
    var hariDropdownExpanded by remember { mutableStateOf(false) }

    // Pesan Notifikasi di Bawah Kotak Input
    var pesanPeringatan by remember { mutableStateOf("") }
    var pesanWarna by remember { mutableStateOf(Color.Gray) }

    LaunchedEffect(Unit) {
        try {
            val response = ApiClient.apiService.getDokter()
            if (response.isSuccessful && response.body()?.status == true) {
                dokterList = response.body()?.data ?: emptyList()
            } else {
                Toast.makeText(context, "Gagal mengambil data dokter", Toast.LENGTH_SHORT).show()
            }
        } catch (e: Exception) {
            Toast.makeText(context, "Error koneksi: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    val daftarSpesialisasi = dokterList.map { it.spesialisasi }.distinct()
    val daftarDokterSesuaiSpesialis = dokterList.filter { it.spesialisasi == spesialisasiTerpilih }

    val jadwalTersedia = dokterTerpilih?.jadwal?.map { it.hari } ?: emptyList()

    // Fungsi Validasi Jam Pintar (Dipanggil otomatis saat user selesai mengetik)
    fun validasiDanKoreksiOtomatis() {
        if (dokterTerpilih == null || hariTerpilih.isEmpty() || inputJam.isEmpty() || inputMenit.isEmpty()) {
            pesanPeringatan = ""
            return
        }

        val jadwalHariItu = dokterTerpilih?.jadwal?.find { it.hari.equals(hariTerpilih, ignoreCase = true) }

        if (jadwalHariItu != null) {
            try {
                val inputWaktuUser = "${inputJam}:${inputMenit}"
                val sdf = SimpleDateFormat("HH:mm", Locale.getDefault())

                val userTime = sdf.parse(inputWaktuUser)
                val startTime = sdf.parse(jadwalHariItu.jam_mulai)
                val endTime = sdf.parse(jadwalHariItu.jam_selesai)

                if (userTime != null && startTime != null && endTime != null) {
                    if (userTime.before(startTime)) {
                        val jamBukaString = jadwalHariItu.jam_mulai.substring(0, 5)
                        inputJam = jamBukaString.split(":")[0]
                        inputMenit = jamBukaString.split(":")[1]
                        pesanPeringatan = "Dokter belum buka! Waktu disesuaikan ke jam buka awal ($jamBukaString)."
                        pesanWarna = Color(0xFFD32F2F)
                    } else if (userTime.after(endTime)) {
                        val jamTutupString = jadwalHariItu.jam_selesai.substring(0, 5)
                        inputJam = jamTutupString.split(":")[0]
                        inputMenit = jamTutupString.split(":")[1]
                        pesanPeringatan = "Dokter sudah tutup! Waktu disesuaikan ke batas tutup ($jamTutupString)."
                        pesanWarna = Color(0xFFD32F2F)
                    } else {
                        pesanPeringatan = "Waktu valid dan tersedia ✓"
                        pesanWarna = Color(0xFF388E3C)
                    }
                }
            } catch (e: Exception) {
                pesanPeringatan = "Format waktu tidak dikenali!"
                pesanWarna = Color.Red
            }
        }
    }

    // =========================================================================
    // PERBAIKAN: Fungsi Hitung Tanggal Nyata (Tidak lagi selalu hari ini)
    // =========================================================================
    fun hitungTanggalDariHari(hari: String): String {
        if (hari.isEmpty()) return ""
        val format = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())

        val calendar = Calendar.getInstance()
        val currentDayOfWeek = calendar.get(Calendar.DAY_OF_WEEK)

        val targetDayOfWeek = when (hari.lowercase(Locale.getDefault())) {
            "minggu" -> Calendar.SUNDAY
            "senin" -> Calendar.MONDAY
            "selasa" -> Calendar.TUESDAY
            "rabu" -> Calendar.WEDNESDAY
            "kamis" -> Calendar.THURSDAY
            "jumat" -> Calendar.FRIDAY
            "sabtu" -> Calendar.SATURDAY
            else -> currentDayOfWeek
        }

        var diff = targetDayOfWeek - currentDayOfWeek
        // Jika harinya sudah lewat (contoh: sekarang rabu, pilih senin), maka tambah 7 hari ke minggu depan
        if (diff < 0) {
            diff += 7
        }

        calendar.add(Calendar.DAY_OF_YEAR, diff)
        return format.format(calendar.time)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "Pendaftaran Layanan Medis",
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF0066CC),
            modifier = Modifier.padding(bottom = 24.dp, top = 8.dp)
        )

        // 1. Pilih Spesialisasi
        ExposedDropdownMenuBox(
            expanded = spesialisasiDropdownExpanded,
            onExpandedChange = { spesialisasiDropdownExpanded = !spesialisasiDropdownExpanded }
        ) {
            OutlinedTextField(
                value = spesialisasiTerpilih.ifEmpty { "Pilih Poli/Spesialis" },
                onValueChange = {},
                readOnly = true,
                label = { Text("Spesialisasi") },
                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = spesialisasiDropdownExpanded) },
                modifier = Modifier.menuAnchor().fillMaxWidth()
            )
            ExposedDropdownMenu(
                expanded = spesialisasiDropdownExpanded,
                onDismissRequest = { spesialisasiDropdownExpanded = false }
            ) {
                daftarSpesialisasi.forEach { spesialis ->
                    DropdownMenuItem(
                        text = { Text(spesialis) },
                        onClick = {
                            spesialisasiTerpilih = spesialis
                            dokterTerpilih = null
                            hariTerpilih = ""
                            inputJam = ""
                            inputMenit = ""
                            pesanPeringatan = ""
                            spesialisasiDropdownExpanded = false
                        }
                    )
                }
            }
        }
        Spacer(modifier = Modifier.height(16.dp))

        // 2. Pilih Dokter
        ExposedDropdownMenuBox(
            expanded = dokterDropdownExpanded,
            onExpandedChange = { if (spesialisasiTerpilih.isNotEmpty()) dokterDropdownExpanded = !dokterDropdownExpanded }
        ) {
            OutlinedTextField(
                value = dokterTerpilih?.nama_dokter ?: "Pilih Dokter",
                onValueChange = {},
                readOnly = true,
                label = { Text("Dokter") },
                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = dokterDropdownExpanded) },
                modifier = Modifier.menuAnchor().fillMaxWidth(),
                enabled = spesialisasiTerpilih.isNotEmpty()
            )
            ExposedDropdownMenu(
                expanded = dokterDropdownExpanded,
                onDismissRequest = { dokterDropdownExpanded = false }
            ) {
                daftarDokterSesuaiSpesialis.forEach { dokter ->
                    DropdownMenuItem(
                        text = { Text(dokter.nama_dokter) },
                        onClick = {
                            dokterTerpilih = dokter
                            hariTerpilih = ""
                            inputJam = ""
                            inputMenit = ""
                            pesanPeringatan = ""
                            dokterDropdownExpanded = false
                        }
                    )
                }
            }
        }
        Spacer(modifier = Modifier.height(16.dp))

        // Info Jadwal Dokter
        dokterTerpilih?.let { doc ->
            Card(
                modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFE3F2FD))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Jadwal Praktek Dokter:", fontWeight = FontWeight.Bold, color = Color(0xFF0066CC))
                    Spacer(modifier = Modifier.height(8.dp))
                    if (doc.jadwal.isEmpty()) {
                        Text("Belum ada jadwal tersedia.", fontSize = 14.sp)
                    } else {
                        doc.jadwal.forEach { jad ->
                            Text("- Hari ${jad.hari}: ${jad.jam_mulai} s/d ${jad.jam_selesai}", fontSize = 14.sp)
                        }
                    }
                }
            }
            Spacer(modifier = Modifier.height(16.dp))
        }

        // 3. Pilih Hari Kunjungan
        ExposedDropdownMenuBox(
            expanded = hariDropdownExpanded,
            onExpandedChange = { if (jadwalTersedia.isNotEmpty()) hariDropdownExpanded = !hariDropdownExpanded }
        ) {
            OutlinedTextField(
                value = hariTerpilih.ifEmpty { "Pilih Hari" },
                onValueChange = {},
                readOnly = true,
                label = { Text("Hari Kunjungan") },
                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = hariDropdownExpanded) },
                modifier = Modifier.menuAnchor().fillMaxWidth(),
                enabled = jadwalTersedia.isNotEmpty()
            )
            ExposedDropdownMenu(
                expanded = hariDropdownExpanded,
                onDismissRequest = { hariDropdownExpanded = false }
            ) {
                jadwalTersedia.forEach { hari ->
                    DropdownMenuItem(
                        text = { Text(hari) },
                        onClick = {
                            hariTerpilih = hari
                            inputJam = ""
                            inputMenit = ""
                            pesanPeringatan = ""
                            hariDropdownExpanded = false
                        }
                    )
                }
            }
        }
        Spacer(modifier = Modifier.height(16.dp))

        // 4. Input Jam Custom Pintar
        if (hariTerpilih.isNotEmpty()) {
            Text("Pilih Waktu Kedatangan (WIB):", modifier = Modifier.align(Alignment.Start), fontSize = 14.sp, fontWeight = FontWeight.Medium)
            Spacer(modifier = Modifier.height(8.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                // Kotak Jam
                OutlinedTextField(
                    value = inputJam,
                    onValueChange = {
                        if (it.length <= 2) {
                            inputJam = it
                            if (it.length == 2 && inputMenit.isEmpty()) {
                                focusManager.moveFocus(androidx.compose.ui.focus.FocusDirection.Right)
                            }
                        }
                    },
                    label = { Text("Jam (00-23)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Next),
                    modifier = Modifier
                        .weight(1f)
                        .onFocusChanged { focusState ->
                            if (!focusState.isFocused) {
                                if (inputJam.length == 1) inputJam = "0$inputJam"
                                validasiDanKoreksiOtomatis()
                            }
                        },
                    singleLine = true
                )

                // Kotak Menit
                OutlinedTextField(
                    value = inputMenit,
                    onValueChange = { if (it.length <= 2) inputMenit = it },
                    label = { Text("Menit") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Next),
                    modifier = Modifier
                        .weight(1f)
                        .onFocusChanged { focusState ->
                            if (!focusState.isFocused) {
                                if (inputMenit.length == 1) inputMenit = "0$inputMenit"
                                validasiDanKoreksiOtomatis()
                            }
                        },
                    singleLine = true
                )
            }

            if (pesanPeringatan.isNotEmpty()) {
                Text(
                    text = pesanPeringatan,
                    color = pesanWarna,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier.padding(top = 12.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // 5. Input Keluhan
        OutlinedTextField(
            value = keluhan,
            onValueChange = { keluhan = it },
            label = { Text("Keluhan / Gejala Awal") },
            modifier = Modifier.fillMaxWidth().height(120.dp),
            maxLines = 4,
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
            keyboardActions = KeyboardActions(onDone = { focusManager.clearFocus() })
        )

        Spacer(modifier = Modifier.height(32.dp))

        // Tombol Submit
        Button(
            onClick = {
                focusManager.clearFocus()
                val idUser = sessionManager.fetchUserId()

                if (idUser == -1 || dokterTerpilih == null || hariTerpilih.isEmpty() || inputJam.isEmpty() || inputMenit.isEmpty()) {
                    Toast.makeText(context, "Mohon lengkapi semua data pendaftaran!", Toast.LENGTH_SHORT).show()
                    return@Button
                }

                // Kalkulasi data nyata
                val tanggalKunjungan = hitungTanggalDariHari(hariTerpilih)
                val jamKunjunganFull = "$inputJam:$inputMenit:00"

                isLoading = true
                coroutineScope.launch {
                    try {
                        val request = PendaftaranRequest(
                            id_user = idUser,
                            id_dokter = dokterTerpilih!!.id_dokter,
                            tanggal_kunjungan = tanggalKunjungan,
                            jam_kunjungan = jamKunjunganFull,
                            keluhan = keluhan
                        )
                        val response = ApiClient.apiService.buatPendaftaran(request)
                        if (response.isSuccessful && response.body()?.status == true) {
                            Toast.makeText(context, "Pendaftaran Sukses!", Toast.LENGTH_LONG).show()
                            onPendaftaranSukses()
                        } else {
                            Toast.makeText(context, response.body()?.message ?: "Gagal mendaftar", Toast.LENGTH_LONG).show()
                        }
                    } catch (e: Exception) {
                        Toast.makeText(context, "Error: ${e.message}", Toast.LENGTH_SHORT).show()
                    } finally {
                        isLoading = false
                    }
                }
            },
            modifier = Modifier.fillMaxWidth().height(50.dp),
            enabled = !isLoading && dokterTerpilih != null && keluhan.isNotEmpty()
        ) {
            if (isLoading) {
                CircularProgressIndicator(color = Color.White, modifier = Modifier.size(24.dp))
            } else {
                Text("BUAT PENDAFTARAN", fontSize = 16.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}