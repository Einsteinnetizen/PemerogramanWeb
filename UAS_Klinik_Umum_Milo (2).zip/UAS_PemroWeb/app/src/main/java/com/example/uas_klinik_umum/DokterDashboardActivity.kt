package com.example.uas_klinik_umum

import android.app.DatePickerDialog
import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ExitToApp
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.List
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.uas_klinik_umum.network.ApiClient
import com.example.uas_klinik_umum.network.AntreanItem
import com.example.uas_klinik_umum.network.AntreanRequest
import com.example.uas_klinik_umum.network.RiwayatDokter
import com.example.uas_klinik_umum.utils.SessionManager
import kotlinx.coroutines.launch
import java.util.Calendar

class DokterDashboardActivity : ComponentActivity() {
    @OptIn(ExperimentalMaterial3Api::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val sessionManager = SessionManager(this)

        val namaDokter = sessionManager.getNama() ?: "Dokter"
        val idUserInt = sessionManager.getUserId()

        setContent {
            // State penampung data dari database
            var daftarAntrean by remember { mutableStateOf<List<AntreanItem>>(emptyList()) }
            var namaDokterFix by remember { mutableStateOf(namaDokter) }
            var isLoading by remember { mutableStateOf(true) }
            var pasienTerpilih by remember { mutableStateOf<AntreanItem?>(null) }
            var showDialogPemeriksaan by remember { mutableStateOf(false) }

            // [BARU] State untuk menyimpan total jumlah pasien dari riwayat
            var totalRiwayat by remember { mutableIntStateOf(0) }

            val coroutineScope = rememberCoroutineScope()

            // 🔴 FUNGSI TARIK DATA DARI DATABASE SAAT HALAMAN DIBUKA
            LaunchedEffect(Unit) {
                if (daftarAntrean.isNotEmpty()) { namaDokterFix = daftarAntrean[0].namaDokter ?: namaDokter }
                coroutineScope.launch {
                    // 1. Ambil Antrean Aktif
                    try {
                        val request = AntreanRequest(id_user = idUserInt)
                        val response = ApiClient.apiService.getAntreanDokter(request)

                        if (response.isSuccessful && response.body() != null) {
                            val resBody = response.body()!!
                            if (resBody.status) {
                                daftarAntrean = resBody.data
                            } else {
                                Toast.makeText(this@DokterDashboardActivity, resBody.message, Toast.LENGTH_SHORT).show()
                            }
                        } else {
                            Toast.makeText(this@DokterDashboardActivity, "Gagal merespon dari server", Toast.LENGTH_SHORT).show()
                        }
                    } catch (e: Exception) {
                        Toast.makeText(this@DokterDashboardActivity, "Error koneksi: ${e.message}", Toast.LENGTH_SHORT).show()
                    }

                    // 2. [BARU] Ambil Riwayat untuk menghitung total pasien yang sudah selesai di-diagnosa
                    try {
                        val respRiwayat = ApiClient.apiService.getRiwayatDokter(idUserInt)
                        if (respRiwayat.isSuccessful && respRiwayat.body()?.status == true) {
                            totalRiwayat = respRiwayat.body()?.data?.size ?: 0
                        }
                    } catch (e: Exception) {
                        // Abaikan jika error
                    } finally {
                        isLoading = false
                    }
                }
            }

            MaterialTheme {
                // State penyimpan Tab Navigasi
                var selectedTab by remember { mutableIntStateOf(0) }

                Scaffold(
                    topBar = {
                        TopAppBar(
                            title = { Text("Dashboard Dokter", fontWeight = FontWeight.Bold) },
                            actions = {
                                IconButton(onClick = {
                                    sessionManager.clearSession()
                                    val intent = Intent(this@DokterDashboardActivity, LoginActivity::class.java)
                                    intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                                    startActivity(intent)
                                    finish()
                                }) {
                                    Icon(
                                        imageVector = Icons.AutoMirrored.Filled.ExitToApp,
                                        contentDescription = "Logout",
                                        tint = MaterialTheme.colorScheme.error
                                    )
                                }
                            },
                            colors = TopAppBarDefaults.topAppBarColors(
                                containerColor = MaterialTheme.colorScheme.primaryContainer
                            )
                        )
                    },
                    bottomBar = {
                        NavigationBar {
                            NavigationBarItem(
                                icon = { Icon(Icons.Default.List, contentDescription = "Antrean") },
                                label = { Text("Antrean Aktif") },
                                selected = selectedTab == 0,
                                onClick = { selectedTab = 0 }
                            )
                            NavigationBarItem(
                                icon = { Icon(Icons.Default.DateRange, contentDescription = "Riwayat") },
                                label = { Text("Riwayat") },
                                selected = selectedTab == 1,
                                onClick = { selectedTab = 1 }
                            )
                        }
                    }
                ) { innerPadding ->
                    Box(modifier = Modifier.padding(innerPadding)) {

                        when (selectedTab) {
                            0 -> { // TAB 0: ANTREAN AKTIF
                                Column(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .padding(16.dp)
                                ) {
                                    Text(text = "Halo Dokter $namaDokterFix", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                                    Text(
                                        text = "Berikut adalah daftar antrean pasien Anda hari ini.",
                                        fontSize = 14.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )

                                    Spacer(modifier = Modifier.height(16.dp))

                                    // WIDGET KOTAK REKAPITULASI
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(16.dp)
                                    ) {
                                        Card(
                                            modifier = Modifier.weight(1f),
                                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)
                                        ) {
                                            Column(modifier = Modifier.padding(16.dp)) {
                                                Text("Total Antrean", fontSize = 12.sp)
                                                Text(
                                                    "${daftarAntrean.size} Pasien",
                                                    fontSize = 20.sp,
                                                    fontWeight = FontWeight.Bold
                                                )
                                            }
                                        }
                                        Card(
                                            modifier = Modifier.weight(1f),
                                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.tertiaryContainer)
                                        ) {
                                            Column(modifier = Modifier.padding(16.dp)) {
                                                Text("Selesai Diperiksa", fontSize = 12.sp)
                                                // [BARU] Menggunakan variabel totalRiwayat yang diambil dari server
                                                Text(
                                                    "$totalRiwayat Pasien",
                                                    fontSize = 20.sp,
                                                    fontWeight = FontWeight.Bold
                                                )
                                            }
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(24.dp))

                                    Text(
                                        "Daftar Antrean Aktif",
                                        fontSize = 16.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        modifier = Modifier.padding(bottom = 8.dp)
                                    )

                                    // LIST PASIEN
                                    if (isLoading) {
                                        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                            CircularProgressIndicator()
                                        }
                                    } else if (daftarAntrean.isEmpty()) {
                                        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                            Text("Belum ada antrean pasien hari ini.")
                                        }
                                    } else {
                                        // Filter: Sembunyikan pasien yang sudah "Selesai" di daftar aktif
                                        // [BARU] Filter: Hanya tampilkan pasien yang berstatus DIPERIKSA
                                        val antreanBelumSelesai = daftarAntrean.filter { it.status.equals("Diperiksa", ignoreCase = true) }

                                        if (antreanBelumSelesai.isEmpty()) {
                                            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                                Text("Belum ada pasien yang berstatus Diperiksa.")
                                            }
                                        } else {
                                            LazyColumn(
                                                verticalArrangement = Arrangement.spacedBy(12.dp),
                                                modifier = Modifier.fillMaxSize()
                                            ) {
                                                items(antreanBelumSelesai) { pasien ->
                                                    CardPasienAntrean(
                                                        pasien = pasien,
                                                        onClick = {
                                                            pasienTerpilih = pasien
                                                            showDialogPemeriksaan = true
                                                        }
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }

                                // DIALOG PEMERIKSAAN
                                if (showDialogPemeriksaan && pasienTerpilih != null) {
                                    DialogPemeriksaanMedis(
                                        pasien = pasienTerpilih!!,
                                        onDismiss = { showDialogPemeriksaan = false },
                                        onSimpan = { diagnosa, gejala, penyakit, obat, totalBayar ->
                                            coroutineScope.launch {
                                                try {
                                                    val cleanBiaya = totalBayar.replace(Regex("[^0-9]"), "").toIntOrNull() ?: 0
                                                    val request = com.example.uas_klinik_umum.network.SimpanPemeriksaanRequest(
                                                        id_pendaftaran = pasienTerpilih!!.idPendaftaran,
                                                        gejala = gejala,
                                                        penyakit = penyakit,
                                                        diagnosa = diagnosa,
                                                        obat = obat,
                                                        total_bayar = cleanBiaya
                                                    )

                                                    val response = ApiClient.apiService.simpanPemeriksaan(request)
                                                    if (response.isSuccessful && response.body()?.status == true) {
                                                        Toast.makeText(this@DokterDashboardActivity, "Pemeriksaan Selesai!", Toast.LENGTH_SHORT).show()
                                                        showDialogPemeriksaan = false
                                                        pasienTerpilih = null

                                                        // Refresh halaman otomatis
                                                        val intent = Intent(this@DokterDashboardActivity, DokterDashboardActivity::class.java)
                                                        startActivity(intent)
                                                        finish()
                                                    } else {
                                                        Toast.makeText(this@DokterDashboardActivity, "Gagal Menyimpan: ${response.body()?.message}", Toast.LENGTH_SHORT).show()
                                                    }
                                                } catch (e: Exception) {
                                                    Toast.makeText(this@DokterDashboardActivity, "Error Koneksi: ${e.message}", Toast.LENGTH_SHORT).show()
                                                }
                                            }
                                        }
                                    )
                                }
                            } // AKHIR TAB 0

                            1 -> { // TAB 1: RIWAYAT
                                LayarRiwayatDokter(idUserInt = idUserInt)
                            } // AKHIR TAB 1
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun CardPasienAntrean(pasien: AntreanItem, onClick: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().clickable { onClick() },
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                color = MaterialTheme.colorScheme.primary,
                shape = RoundedCornerShape(50),
                modifier = Modifier.size(50.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Text(text = pasien.noAntrean.toString(), color = MaterialTheme.colorScheme.onPrimary, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                }
            }
            Spacer(modifier = Modifier.width(16.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(text = pasien.namaPasien, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Text(text = "Keluhan: ${pasien.keluhan}", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Text(text = pasien.status, fontWeight = FontWeight.SemiBold, fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
        }
    }
}

@Composable
fun DialogPemeriksaanMedis(
    pasien: AntreanItem,
    onDismiss: () -> Unit,
    onSimpan: (String, String, String, String, String) -> Unit
) {
    var gejala by remember { mutableStateOf("") }
    var penyakit by remember { mutableStateOf("") }
    var diagnosa by remember { mutableStateOf("") }
    var obat by remember { mutableStateOf("") }

    var isTidakPerluObat by remember { mutableStateOf(false) }
    var isHanyaKonsultasi by remember { mutableStateOf(false) }

    val tarif = pasien.tarifKonsultasi ?: 0
    val formatter = java.text.NumberFormat.getNumberInstance(java.util.Locale("id", "ID"))

//    LaunchedEffect(isHanyaKonsultasi) {
//        if (isHanyaKonsultasi) {
//            isTidakPerluObat = true
//            obat = "Hanya Konsultasi"
//        } else {
//            if (obat == "Hanya Konsultasi") obat = ""
//        }
//    }

    LaunchedEffect(isTidakPerluObat) {
        if (isTidakPerluObat && !isHanyaKonsultasi) {
            obat = "Tidak Perlu Obat"
        } else if (!isTidakPerluObat && !isHanyaKonsultasi) {
            if (obat == "Tidak Perlu Obat") obat = ""
        }
    }

    // [PERBAIKAN] Dokter hanya memproses tagihan tarif konsultasi
    val finalTotal = tarif

    AlertDialog(
        onDismissRequest = { onDismiss() },
        title = { Text(text = "Periksa: ${pasien.namaPasien}", fontSize = 18.sp, fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                Text("Keluhan: ${pasien.keluhan}", style = MaterialTheme.typography.bodyMedium, color = Color.Gray)
                Text("Tarif Konsultasi: Rp ${formatter.format(tarif)}", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = isTidakPerluObat, onCheckedChange = { isTidakPerluObat = it; if(!it) isHanyaKonsultasi = false })
                        Text("Tanpa Obat", fontSize = 14.sp)
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = isHanyaKonsultasi, onCheckedChange = { isHanyaKonsultasi = it })
                        Text("Hanya Konsultasi", fontSize = 14.sp)
                    }
                }

                OutlinedTextField(value = gejala, onValueChange = { gejala = it }, label = { Text("Gejala") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                OutlinedTextField(value = penyakit, onValueChange = { penyakit = it }, label = { Text("Penyakit") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                OutlinedTextField(value = diagnosa, onValueChange = { diagnosa = it }, label = { Text("Diagnosa") }, modifier = Modifier.fillMaxWidth(), singleLine = true)

                OutlinedTextField(
                    value = obat,
                    onValueChange = { obat = it },
                    label = { Text("Resep Obat") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    enabled = !isTidakPerluObat
                )

                HorizontalDivider()
                Text("Total Tagihan: Rp ${formatter.format(finalTotal)}", fontWeight = FontWeight.ExtraBold, color = Color(0xFFD32F2F), fontSize = 16.sp)
                Text("*Biaya obat akan dihitung oleh kasir", fontSize = 11.sp, color = Color.Gray)
            }
        },
        confirmButton = {
            Button(
                onClick = { if (diagnosa.isNotEmpty()) onSimpan(diagnosa, gejala, penyakit, obat, finalTotal.toString()) },
                enabled = diagnosa.isNotEmpty()
            ) { Text("SELESAI") }
        },
        dismissButton = { TextButton(onClick = { onDismiss() }) { Text("Batal") } }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LayarRiwayatDokter(idUserInt: Int) {
    val coroutineScope = rememberCoroutineScope()
    val context = LocalContext.current
    var riwayatList by remember { mutableStateOf<List<RiwayatDokter>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }

    var day by remember { mutableStateOf("") }
    var month by remember { mutableStateOf("") }
    var year by remember { mutableStateOf("") }

    LaunchedEffect(idUserInt) {
        coroutineScope.launch {
            try {
                val response = ApiClient.apiService.getRiwayatDokter(idUserInt)
                if (response.isSuccessful && response.body()?.status == true) {
                    riwayatList = response.body()?.data ?: emptyList()
                }
            } catch (e: Exception) {
                // Tangani error
            } finally {
                isLoading = false
            }
        }
    }

    val calendar = Calendar.getInstance()
    val datePickerDialog = DatePickerDialog(
        context,
        { _, selectedYear, selectedMonth, selectedDay ->
            year = selectedYear.toString()
            month = String.format("%02d", selectedMonth + 1)
            day = String.format("%02d", selectedDay)
        },
        calendar.get(Calendar.YEAR),
        calendar.get(Calendar.MONTH),
        calendar.get(Calendar.DAY_OF_MONTH)
    )

    val filteredList = riwayatList.filter { riwayat ->
        val parts = riwayat.tanggal_kunjungan.split("-")
        if (parts.size == 3) {
            val dbYear = parts[0]
            val dbMonth = parts[1]
            val dbDay = parts[2]
            val matchYear = year.isEmpty() || dbYear.contains(year)
            val matchMonth = month.isEmpty() || dbMonth.contains(month)
            val matchDay = day.isEmpty() || dbDay.contains(day)
            matchYear && matchMonth && matchDay
        } else true
    }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text("Riwayat Pasien Anda", fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(16.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = day, onValueChange = { if (it.length <= 2) day = it },
                label = { Text("DD") }, modifier = Modifier.weight(1f), singleLine = true
            )
            OutlinedTextField(
                value = month, onValueChange = { if (it.length <= 2) month = it },
                label = { Text("MM") }, modifier = Modifier.weight(1f), singleLine = true
            )
            OutlinedTextField(
                value = year, onValueChange = { if (it.length <= 4) year = it },
                label = { Text("YYYY") }, modifier = Modifier.weight(1.5f), singleLine = true
            )
            IconButton(
                onClick = { datePickerDialog.show() },
                modifier = Modifier.size(54.dp)
            ) {
                Icon(Icons.Default.DateRange, contentDescription = "Pilih Tanggal", tint = MaterialTheme.colorScheme.primary)
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        if (isLoading) {
            CircularProgressIndicator(modifier = Modifier.align(Alignment.CenterHorizontally))
        } else if (filteredList.isEmpty()) {
            Text("Tidak ada riwayat ditemukan pada tanggal tersebut.", color = Color.Gray)
        } else {
            LazyColumn(modifier = Modifier.fillMaxSize()) {
                items(filteredList) { riwayat ->
                    Card(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                Text("Tanggal: ${riwayat.tanggal_kunjungan}", fontWeight = FontWeight.Bold)
                                Text("Jam: ${riwayat.jam_kunjungan}", color = Color.Gray)
                            }
                            HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))
                            Text(riwayat.nama_pasien, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                            Text("JK: ${riwayat.jenis_kelamin}", fontSize = 14.sp)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("Diagnosa: ${riwayat.diagnosa}", fontSize = 14.sp)
                            Text("Tindakan: ${riwayat.tindakan}", fontSize = 14.sp)
                        }
                    }
                }
            }
        }
    }
}