package com.example.uas_klinik_umum

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.uas_klinik_umum.network.*
import kotlinx.coroutines.launch
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TiketScreen(idUser: Int, onBackClick: () -> Unit) {
    val coroutineScope = rememberCoroutineScope()
    var tiketList by remember { mutableStateOf<List<TiketAntrian>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(idUser) {
        coroutineScope.launch {
            try {
                val response = ApiClient.apiService.getTiketAktif(idUser)
                if (response.isSuccessful && response.body()?.status == true) {
                    tiketList = response.body()?.data ?: emptyList()
                } else {
                    errorMessage = response.body()?.message ?: "Belum ada antrian aktif."
                }
            } catch (e: Exception) {
                errorMessage = "Gagal terhubung ke server: ${e.message}"
            } finally {
                isLoading = false
            }
        }
    }

    // FUNGSI BARU: Mengubah Spesialisasi menjadi Kode Awalan (Prefix)
    fun dapatkanKodePoli(spesialisasi: String): String {
        return when {
            spesialisasi.contains("THT", ignoreCase = true) -> "THT"
            spesialisasi.contains("Gigi", ignoreCase = true) -> "GIG"
            spesialisasi.contains("Anak", ignoreCase = true) -> "ANK"
            spesialisasi.contains("Umum", ignoreCase = true) -> "UMM"
            spesialisasi.contains("Mata", ignoreCase = true) -> "MTA"
            else -> spesialisasi.take(3).uppercase(Locale.getDefault()) // Ambil 3 huruf pertama jika tidak ada di daftar
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("E-Tiket Aktif", color = Color.White) },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF0066CC),
                    titleContentColor = Color.White
                )
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(Color(0xFFF5F5F5)),
            contentAlignment = Alignment.TopCenter
        ) {
            if (isLoading) {
                CircularProgressIndicator(modifier = Modifier.padding(top = 50.dp))
            } else if (errorMessage != null) {
                Column(
                    modifier = Modifier.fillMaxSize().padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Text(
                        text = errorMessage!!,
                        color = Color.Gray,
                        textAlign = TextAlign.Center,
                        fontSize = 16.sp
                    )
                    Spacer(modifier = Modifier.height(24.dp))
                    Button(onClick = onBackClick) {
                        Text("Kembali ke Beranda")
                    }
                }
            } else {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp)
                        .verticalScroll(rememberScrollState()),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    if (tiketList.isEmpty()) {
                        Spacer(modifier = Modifier.height(80.dp))
                        Text(
                            text = "Anda tidak memiliki antrean aktif saat ini.",
                            color = Color.Gray,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Medium,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(horizontal = 24.dp)
                        )
                    }
                    tiketList.forEach { tiket ->

                        // PROSES PEMBENTUKAN KODE TIKET FINAL (Contoh: THT-001)
                        val prefix = dapatkanKodePoli(tiket.spesialisasi)
                        // Ubah angka 1 menjadi 001, 12 menjadi 012
                        val nomorFormat =
                            String.format(Locale.getDefault(), "%03d", tiket.nomor_antrean)
                        val kodeTiketTampil = "$prefix-$nomorFormat"

                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 16.dp),
                            shape = RoundedCornerShape(12.dp),
                            elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.White)
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(24.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    "E-TIKET ANTREAN",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 18.sp,
                                    color = Color.DarkGray
                                )
                                Spacer(modifier = Modifier.height(16.dp))

                                Text(
                                    text = "Nomor Antrean",
                                    fontSize = 14.sp,
                                    color = Color.Gray
                                )
                                // Tampilkan Kode Gabungan
                                Text(
                                    text = kodeTiketTampil,
                                    fontSize = 48.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF0066CC)
                                )

                                Spacer(modifier = Modifier.height(24.dp))
                                HorizontalDivider(color = Color.LightGray, thickness = 1.dp)
                                Spacer(modifier = Modifier.height(16.dp))

                                RowInfoTiket("Nama Dokter", tiket.nama_dokter)
                                RowInfoTiket("Poli/Spesialis", tiket.spesialisasi)
                                RowInfoTiket("Tanggal", tiket.tanggal_kunjungan)
                                RowInfoTiket("Jam", "${tiket.jam_kunjungan} WIB")

                                val statusColor = when (tiket.status_layanan.uppercase()) {
                                    "DIPROSES" -> Color(0xFFE65100) // Warna Oranye
                                    "PEMBAYARAN" -> Color(0xFF2E7D32) // Warna Hijau
                                    else -> Color.DarkGray
                                }

// 2. Tampilkan baris "Status" dengan warna dinamis (tanpa memakai RowInfoTiket biasa)
                                Row(
                                    modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text("Status", color = Color.Gray, fontSize = 14.sp)
                                    Text(
                                        text = tiket.status_layanan.uppercase(),
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp,
                                        color = statusColor
                                    )
                                }

// 3. Munculkan detail medis & tagihan jika statusnya PEMBAYARAN
                                if (tiket.status_layanan.uppercase() == "PEMBAYARAN") {
                                    Spacer(modifier = Modifier.height(16.dp))
                                    HorizontalDivider(
                                        color = Color.LightGray,
                                        thickness = 1.dp,
                                        modifier = Modifier.padding(bottom = 16.dp)
                                    )

                                    Text(
                                        "Detail Pemeriksaan & Tagihan",
                                        fontWeight = FontWeight.Bold,
                                        color = Color.DarkGray,
                                        fontSize = 16.sp,
                                        modifier = Modifier.align(Alignment.Start)
                                    )
                                    Spacer(modifier = Modifier.height(8.dp))

                                    RowInfoTiket("Diagnosa Medis", tiket.diagnosa ?: "-")
                                    RowInfoTiket("Tindakan & Obat", tiket.tindakan ?: "-")

                                    Spacer(modifier = Modifier.height(8.dp))

                                    // Format Rupiah (Contoh: Rp 1.500.000)
                                    val formatter = java.text.NumberFormat.getNumberInstance(
                                        java.util.Locale(
                                            "id",
                                            "ID"
                                        )
                                    )
                                    val formattedTagihan =
                                        "Rp " + formatter.format(tiket.total_tagihan ?: 0)

                                    Row(
                                        modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(
                                            "Total Tagihan",
                                            color = Color.Black,
                                            fontSize = 16.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            formattedTagihan,
                                            color = Color(0xFFD32F2F),
                                            fontSize = 18.sp,
                                            fontWeight = FontWeight.ExtraBold
                                        )
                                    }

                                    Spacer(modifier = Modifier.height(12.dp))
                                    Card(
                                        colors = CardDefaults.cardColors(
                                            containerColor = Color(
                                                0xFFE8F5E9
                                            )
                                        ),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Text(
                                            text = "Pemeriksaan selesai! Silakan menuju Kasir untuk melunasi tagihan di atas.",
                                            color = Color(0xFF1B5E20),
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.Medium,
                                            textAlign = TextAlign.Center,
                                            modifier = Modifier.padding(12.dp).fillMaxWidth()
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun RowInfoTiket(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, color = Color.Gray, fontSize = 14.sp)
        Text(value, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, textAlign = TextAlign.End, modifier = Modifier.weight(1f))
    }
}