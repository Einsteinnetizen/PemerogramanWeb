package com.example.uas_klinik_umum

import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ExitToApp
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.uas_klinik_umum.utils.SessionManager

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileScreen(sessionManager: SessionManager) {
    val context = LocalContext.current

    // 1. [TAMBAHAN] Ambil nama dan email dari SessionManager
    val namaPasien = sessionManager.getNama()
    val emailPasien = sessionManager.getEmail() ?: "email@klinik.com"

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Profil Saya", fontWeight = FontWeight.Bold) },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = Color.White
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(modifier = Modifier.height(24.dp))

            // Avatar / Foto Profil Tiruan
            Box(
                modifier = Modifier
                    .size(100.dp)
                    .background(Color.Gray.copy(alpha = 0.2f), shape = CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Person,
                    contentDescription = "Avatar",
                    modifier = Modifier.size(64.dp),
                    tint = MaterialTheme.colorScheme.primary
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // 2. [PERBAIKAN] Tampilkan Nama Asli
            Text(
                text = namaPasien,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold
            )

            // 3. [TAMBAHAN BONUS] Tampilkan Email di bawah nama agar lebih profesional
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = emailPasien,
                fontSize = 14.sp,
                color = Color.Gray
            )

            Spacer(modifier = Modifier.height(40.dp))
            Divider()

            // OPSI LOGOUT (Berbentuk Baris Menu yang Elegan)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable {
                        // 1. Bersihkan sesi login
                        sessionManager.clearSession()

                        // 2. Tendang kembali ke halaman LoginActivity
                        val intent = Intent(context, LoginActivity::class.java).apply {
                            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                        }
                        context.startActivity(intent)
                    }
                    .padding(vertical = 16.dp, horizontal = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.ExitToApp,
                    contentDescription = "Logout",
                    tint = Color(0xFFD32F2F) // Warna Merah
                )
                Spacer(modifier = Modifier.width(16.dp))
                Text(
                    text = "Keluar dari Akun",
                    fontSize = 16.sp,
                    color = Color(0xFFD32F2F),
                    fontWeight = FontWeight.SemiBold
                )
            }
            Divider()
        }
    }
}