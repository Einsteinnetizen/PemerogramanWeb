package com.example.uas_klinik_umum.utils

import android.content.Context
import android.content.SharedPreferences

class SessionManager(context: Context) {
    private val sharedPreferences: SharedPreferences = context.getSharedPreferences("KlinikUmumSession", Context.MODE_PRIVATE)
    private val editor: SharedPreferences.Editor = sharedPreferences.edit()

    companion object {
        private const val KEY_IS_LOGGED_IN = "isLoggedIn"
        private const val KEY_USER_ID = "userId"
        private const val KEY_EMAIL = "email"
        private const val KEY_ROLE = "role"
        private const val KEY_NAMA = "nama"
        private const val KEY_TOKEN = "token"
        private const val KEY_PROFILE_STATUS = "profileStatus" // Tambahan jika diperlukan oleh dashboard pasien
    }

    // Fungsi untuk menyimpan data setelah login berhasil (Dipakai di LoginActivity baru)
    fun saveSession(idUser: Int, email: String, role: String, nama: String?, token: String?) {
        editor.putBoolean(KEY_IS_LOGGED_IN, true)
        editor.putInt(KEY_USER_ID, idUser)
        editor.putString(KEY_EMAIL, email)
        editor.putString(KEY_ROLE, role)
        editor.putString(KEY_NAMA, nama ?: "Pengguna")
        editor.putString(KEY_TOKEN, token ?: "")
        editor.apply()
    }

    // Cek apakah user sudah login atau belum
    fun isLoggedIn(): Boolean {
        return sharedPreferences.getBoolean(KEY_IS_LOGGED_IN, false)
    }

    // 🔴 DUA FUNGSI UTAMA YANG DIPANGGIL DI DASHBOARD DOKTER
    fun getUserId(): Int {
        return sharedPreferences.getInt(KEY_USER_ID, -1)
    }

    fun getNama(): String {
        return sharedPreferences.getString(KEY_NAMA, "Pengguna") ?: "Pengguna"
    }

    // Fungsi pembaca tambahan standar
    fun getEmail(): String? {
        return sharedPreferences.getString(KEY_EMAIL, null)
    }

    fun getRole(): String? {
        return sharedPreferences.getString(KEY_ROLE, null)
    }

    fun getToken(): String? {
        return sharedPreferences.getString(KEY_TOKEN, null)
    }

    // Clear session saat menekan tombol Logout
    fun clearSession() {
        editor.clear()
        editor.apply()
    }

    // =====================================================================
    // 🔴 JEMBATAN ALIAS: AGAR PASIEN DASHBOARD & PENDAFTARAN SCREEN TIDAK CRASH/ERROR
    // =====================================================================

    fun fetchUserId(): Int {
        return getUserId()
    }

    fun fetchAuthToken(): String? {
        return getToken()
    }

    fun fetchUserRole(): String? {
        return getRole()
    }

    

    // Fungsi ini ditambahkan jika file pasien lama membutuhkannya untuk menyimpan status profil
    fun saveProfileStatus(isComplete: Boolean) {
        editor.putBoolean(KEY_PROFILE_STATUS, isComplete)
        editor.apply()
    }
}