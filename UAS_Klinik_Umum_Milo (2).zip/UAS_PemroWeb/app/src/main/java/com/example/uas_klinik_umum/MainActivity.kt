package com.example.uas_klinik_umum

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import com.example.uas_klinik_umum.utils.SessionManager

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val sessionManager = SessionManager(this)
        val token = sessionManager.fetchAuthToken()
        val role = sessionManager.fetchUserRole()

        // Satpam Penyeleksi: Mengecek apakah ada token/sesi yang tersimpan di HP
        if (token != null && role != null) {
            // JIKA SUDAH LOGIN: Lempar ke Dashboard masing-masing
            val intent = when (role.lowercase()) {
                "admin" -> Intent(this, AdminDashboardActivity::class.java)
                "dokter" -> Intent(this, DokterDashboardActivity::class.java)
                else -> Intent(this, PasienDashboardActivity::class.java)
            }
            startActivity(intent)

        } else {
            // JIKA BELUM LOGIN / BARU INSTALL: Lempar ke halaman LoginActivity
            startActivity(Intent(this, LoginActivity::class.java))
        }

        // Hancurkan MainActivity setelah melempar pengguna, agar pengguna tidak
        // bisa menekan tombol "Back" dan kembali ke layar kosong ini.
        finish()
    }
}