package com.example.uas_klinik_umum

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.AddCircle
import androidx.compose.material.icons.filled.Person // Diimpor untuk ikon Profil
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.uas_klinik_umum.utils.SessionManager

class PasienDashboardActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val sessionManager = SessionManager(this)

        // Mengambil ID User asli dari session
        val currentUserId = sessionManager.fetchUserId()
        val namaPasien = sessionManager.getNama()

        setContent {
            MaterialTheme {
                val navController = rememberNavController()
                Scaffold(
                    bottomBar = { BottomNavigationBar(navController) }
                ) { innerPadding ->
                    Box(modifier = Modifier.padding(innerPadding)) {
                        NavigationGraph(navController, sessionManager, currentUserId)
                    }
                }
            }
        }
    }
}

@Composable
fun BottomNavigationBar(navController: NavHostController) {
    // KUNCI PERBAIKAN: Menggunakan objek Screen untuk menghindari typo penulisan rute
    val items = listOf(
        BottomNavItem("Beranda", Screen.Home.route, Icons.Default.Home),
        BottomNavItem("Daftar", Screen.Daftar.route, Icons.Default.AddCircle),
        BottomNavItem("Riwayat", Screen.Riwayat.route, Icons.Default.List),
        BottomNavItem("Profil", Screen.Profil.route, Icons.Default.Person)
    )

    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route

    NavigationBar {
        items.forEach { item ->
            NavigationBarItem(
                icon = { Icon(item.icon, contentDescription = item.title) },
                label = { Text(item.title) },
                selected = currentRoute == item.route,
                onClick = {
                    if (currentRoute != item.route) {
                        navController.navigate(item.route) {
                            popUpTo(navController.graph.startDestinationId) { saveState = true }
                            launchSingleTop = true
                            restoreState = true
                        }
                    }
                }
            )
        }
    }
}

@Composable
fun NavigationGraph(navController: NavHostController, sessionManager: SessionManager, currentUserId: Int) {
    // KUNCI PERBAIKAN: startDestination dikunci menggunakan struktur objek rute aman
    NavHost(navController, startDestination = Screen.Home.route) {

        composable(Screen.Home.route) {
            HomeScreen(
                namaPasien = sessionManager.getNama(), // LANGSUNG PANGGIL DI SINI SAJA
                onMenuDaftarClick = {
                    navController.navigate(Screen.Daftar.route) {
                        popUpTo(Screen.Home.route) { saveState = true }
                        launchSingleTop = true
                        restoreState = true
                    }
                },
                onMenuTiketClick = {
                    navController.navigate(Screen.Tiket.route) {
                        popUpTo(Screen.Home.route) { saveState = true }
                        launchSingleTop = true
                        restoreState = true
                    }
                }
            )
        }

        composable(Screen.Daftar.route) {
            PendaftaranScreen(
                sessionManager = sessionManager,
                onPendaftaranSukses = {
                    navController.navigate(Screen.Tiket.route) {
                        popUpTo(Screen.Home.route)
                    }
                }
            )
        }

        composable(Screen.Tiket.route) {
            TiketScreen(
                idUser = currentUserId,
                onBackClick = { navController.navigate(Screen.Home.route) }
            )
        }

        composable(Screen.Riwayat.route) {
            RiwayatScreen(idUser = currentUserId)
        }

        composable(Screen.Profil.route) {
            ProfileScreen(sessionManager = sessionManager)
        }
    }
}

/**
 * KUNCI UTAMA PENGHINDAR HUMAN ERROR:
 * Menggunakan Sealed Class sebagai struktur data rute tunggal yang bersifat Type-Safe.
 * Pengembang tidak bisa lagi asal menulis string rute secara manual di komponen lain.
 */
sealed class Screen(val route: String) {
    object Home : Screen("pasien_home")
    object Daftar : Screen("pasien_daftar")
    object Tiket : Screen("pasien_tiket")
    object Riwayat : Screen("pasien_riwayat")
    object Profil : Screen("pasien_profil")
}

data class BottomNavItem(
    val title: String,
    val route: String,
    val icon: androidx.compose.ui.graphics.vector.ImageVector
)