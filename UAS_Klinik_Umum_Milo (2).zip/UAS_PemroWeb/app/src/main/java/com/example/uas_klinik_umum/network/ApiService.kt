package com.example.uas_klinik_umum.network

import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Query

interface ApiService {
    @POST("login.php")
    suspend fun login(@Body request: LoginRequest): Response<LoginResponse>

    @POST("../forgot-password.php")
    suspend fun forgotPassword(@Body request: ForgotPasswordRequest): Response<GeneralResponse>

    @POST("register_akun.php")
    suspend fun registerAkun(@Body request: RegisterAccountRequest): Response<RegisterAccountResponse>

    @POST("../simpan_profil.php")
    suspend fun simpanProfil(@Body request: ProfilPasienRequest): Response<GeneralResponse>

    @GET("get_dokter.php")
    suspend fun getDokter(): Response<GetDokterResponse>

    @POST("buat_pendaftaran.php")
    suspend fun buatPendaftaran(@Body request: PendaftaranRequest): Response<PendaftaranResponse>

    @GET("get_tiket.php")
    suspend fun getTiketAktif(@Query("id_user") idUser: Int): Response<GetTiketResponse>

    // =================================================================
    // 🔴 ENDPOINT UNTUK MENGAMBIL ANTREAN PASIEN OLEH DOKTER
    // =================================================================
    @POST("get_antrean_dokter.php")
    suspend fun getAntreanDokter(@Body request: AntreanRequest): Response<AntreanResponse>

    @GET("get_riwayat.php")
    suspend fun getRiwayat(@Query("id_user") idUser: Int): Response<GetRiwayatResponse>

    // =================================================================
    // 🔴 ENDPOINT UNTUK ADMIN
    // =================================================================
    @GET("get_obat.php")
    suspend fun getObat(): Response<GetObatResponse>

    @GET("get_pembayaran.php")
    suspend fun getPembayaran(): Response<GetPembayaranResponse>

    @GET("get_antrean_admin.php")
    suspend fun getAntreanAdmin(): Response<AntreanResponse>

    @POST("update_status_pembayaran.php")
    suspend fun updateStatusBayar(@Query("id_pembayaran") idPembayaran: Int, @Query("status") status: String): Response<GeneralResponse>

    @POST("update_stok_obat.php")
    suspend fun updateStokObat(@Query("id_obat") idObat: Int, @Query("jumlah") jumlah: Int): Response<GeneralResponse>

    @POST("update_status_antrean.php")
    suspend fun updateStatusAntrean(
        @Query("id_pendaftaran") idPendaftaran: Int,
        @Query("status") status: String
    ): Response<GeneralResponse>

    @POST("add_obat.php")
    suspend fun addObat(
        @Query("nama_obat") nama: String,
        @Query("satuan") satuan: String,
        @Query("harga_jual") harga: Double,
        @Query("stok") stok: Int
    ): Response<GeneralResponse>

    @POST("edit_obat.php")
    suspend fun editObat(
        @Query("id_obat") id: Int,
        @Query("nama_obat") nama: String,
        @Query("satuan") satuan: String,
        @Query("harga_jual") harga: Double,
        @Query("stok") stok: Int
    ): Response<GeneralResponse>

    @POST("delete_obat.php")
    suspend fun deleteObat(@Query("id_obat") id: Int): Response<GeneralResponse>

    @POST("simpan_pemeriksaan.php")
    suspend fun simpanPemeriksaan(@Body request: SimpanPemeriksaanRequest): Response<GeneralResponse>

    @GET("get_antrean_kasir.php")
    suspend fun getAntreanKasir(): Response<KasirResponse>

    // [BARU] Konfirmasi pembayaran sekarang mengirimkan harga dan BPJS
    @POST("konfirmasi_pembayaran.php")
    suspend fun konfirmasiPembayaran(@Body request: KonfirmasiPembayaranRequest): Response<GeneralResponse>

    // [BARU] Mengambil data asuransi
    @GET("get_asuransi.php")
    suspend fun getAsuransi(): Response<GetAsuransiResponse>

    @GET("get_riwayat_dokter.php")
    suspend fun getRiwayatDokter(@Query("id_user") idUser: Int): Response<GetRiwayatDokterResponse>

    @GET("get_riwayat_pembayaran.php")
    suspend fun getRiwayatPembayaran(): Response<GetPembayaranResponse>

    @GET("get_users_admin.php")
    suspend fun getUsersAdmin(): Response<GetUsersResponse>

    @GET("get_laporan_admin.php")
    suspend fun getLaporanAdmin(): Response<GetLaporanResponse>

    @GET("get_mitra_asuransi.php")
    suspend fun getMitraAsuransi(): Response<MitraAsuransiResponse>

    // [BARU] Validasi kartu BPJS/Asuransi sebelum pemotongan harga
    @POST("cek_validasi_bpjs.php")
    suspend fun cekValidasiBpjs(@Body request: Map<String, String>): Response<GeneralResponse>

    @POST("simpan_pemeriksaan.php")
    suspend fun simpanPemeriksaan(
        @Query("id_pendaftaran") idPendaftaran: Int,
        @Query("diagnosa") diagnosa: String,
        @Query("gejala") gejala: String,
        @Query("penyakit") penyakit: String,
        @Query("obat") obat: String,
        @Query("total_bayar") totalBayar: String
    ): Response<GeneralResponse>
}

