package com.example.uas_klinik_umum

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.input.key.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.uas_klinik_umum.network.ApiClient
import com.example.uas_klinik_umum.network.ForgotPasswordRequest
import kotlinx.coroutines.launch

class ForgotPasswordActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                ForgotPasswordScreen(onFinish = {
                    Toast.makeText(this, "Password berhasil diubah! Silakan Login", Toast.LENGTH_LONG).show()
                    val intent = Intent(this, LoginActivity::class.java)
                    intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                    startActivity(intent)
                    finish()
                }, onBack = { finish() })
            }
        }
    }
}

@OptIn(ExperimentalComposeUiApi::class, ExperimentalMaterial3Api::class)
@Composable
fun ForgotPasswordScreen(onFinish: () -> Unit, onBack: () -> Unit) {
    var step by remember { mutableStateOf(1) } // Step 1: Email, Step 2: OTP, Step 3: Password Baru
    var email by remember { mutableStateOf("") }
    var newPassword by remember { mutableStateOf("") }
    var isLoading by remember { mutableStateOf(false) }

    // State untuk 6 kotak OTP terpisah
    val otpValues = remember { mutableStateListOf("", "", "", "", "", "") }
    val focusRequesters = remember { List(6) { FocusRequester() } }

    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val focusManager = LocalFocusManager.current

    // Fungsi utama pengiriman data API
    val handleNextStep = {
        val otpString = otpValues.joinToString("")

        var validasiInput = true
        if (step == 1 && email.isEmpty()) validasiInput = false
        if (step == 2 && otpString.length < 6) validasiInput = false
        if (step == 3 && newPassword.length < 6) {
            Toast.makeText(context, "Password minimal 6 karakter!", Toast.LENGTH_SHORT).show()
            validasiInput = false
        }

        if (validasiInput) {
            isLoading = true
            coroutineScope.launch {
                try {
                    val action = when (step) {
                        1 -> "request_otp"
                        2 -> "verify_otp"
                        else -> "reset_password"
                    }
                    val request = ForgotPasswordRequest(
                        action = action,
                        email = email,
                        otp = otpString,
                        new_password = newPassword
                    )

                    val response = ApiClient.apiService.forgotPassword(request)
                    if (response.isSuccessful && response.body()?.status == true) {
                        if (step == 3) onFinish() else step++
                    } else {
                        Toast.makeText(context, response.body()?.message ?: "Gagal memproses", Toast.LENGTH_LONG).show()
                    }
                } catch (e: Exception) {
                    Toast.makeText(context, "Error: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
                } finally {
                    isLoading = false
                }
            }
        }
    }

    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = when (step) {
                1 -> "LUPA PASSWORD"
                2 -> "VERIFIKASI OTP"
                else -> "PASSWORD BARU"
            },
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold
        )

        Text(
            text = when (step) {
                1 -> "Masukkan email akun Anda untuk menerima kode verifikasi OTP"
                2 -> "Masukkan 6 digit kode OTP yang dikirim ke email $email"
                else -> "Masukkan kata sandi baru yang aman untuk akun Anda"
            },
            fontSize = 13.sp,
            color = LocalContentColor.current.copy(alpha = 0.6f),
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(top = 8.dp, bottom = 32.dp)
        )

        // ==========================================
        // STEP 1: FORM INPUT EMAIL
        // ==========================================
        if (step == 1) {
            OutlinedTextField(
                value = email,
                onValueChange = { email = it },
                label = { Text("Email Terdaftar") },
                modifier = Modifier.fillMaxWidth(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email, imeAction = ImeAction.Done),
                keyboardActions = KeyboardActions(onDone = {
                    focusManager.clearFocus()
                    handleNextStep()
                })
            )
        }

        // ==========================================
        // STEP 2: FORM 6 KOTAK KODE OTP PINTAR
        // ==========================================
        if (step == 2) {
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally),
                modifier = Modifier.fillMaxWidth()
            ) {
                for (i in 0..5) {
                    OutlinedTextField(
                        value = otpValues[i],
                        onValueChange = { input ->
                            if (input.length <= 1) {
                                otpValues[i] = input
                                // Jika mengisi angka, otomatis lompat maju ke kotak selanjutnya
                                if (input.isNotEmpty() && i < 5) {
                                    focusRequesters[i + 1].requestFocus()
                                }
                                // Jika 6 angka sudah terisi penuh di kotak terakhir, langsung kirim otomatis
                                if (otpValues.joinToString("").length == 6) {
                                    focusManager.clearFocus()
                                    handleNextStep()
                                }
                            }
                        },
                        modifier = Modifier
                            .width(48.dp)
                            .focusRequester(focusRequesters[i])
                            .onKeyEvent { keyEvent ->
                                // Deteksi tombol Backspace / Hapus kosong untuk lompat mundur ke kotak sebelumnya
                                if (keyEvent.type == KeyEventType.KeyDown && keyEvent.key == Key.Backspace && otpValues[i].isEmpty() && i > 0) {
                                    otpValues[i - 1] = ""
                                    focusRequesters[i - 1].requestFocus()
                                    true
                                } else {
                                    false
                                }
                            },
                        textStyle = LocalTextStyle.current.copy(
                            textAlign = TextAlign.Center,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        ),
                        keyboardOptions = KeyboardOptions(
                            keyboardType = KeyboardType.Number,
                            imeAction = if (i == 5) ImeAction.Done else ImeAction.Next
                        ),
                        keyboardActions = KeyboardActions(
                            onDone = {
                                focusManager.clearFocus()
                                handleNextStep()
                            }
                        ),
                        singleLine = true
                    )
                }
            }

            // Fokus otomatis ke kotak pertama saat halaman verifikasi terbuka
            LaunchedEffect(Unit) {
                focusRequesters[0].requestFocus()
            }
        }

        // ==========================================
        // STEP 3: FORM INPUT PASSWORD BARU
        // ==========================================
        if (step == 3) {
            OutlinedTextField(
                value = newPassword,
                onValueChange = { newPassword = it },
                label = { Text("Password Baru Anda") },
                visualTransformation = PasswordVisualTransformation(),
                modifier = Modifier.fillMaxWidth(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password, imeAction = ImeAction.Done),
                keyboardActions = KeyboardActions(onDone = {
                    focusManager.clearFocus()
                    handleNextStep()
                })
            )
        }

        Spacer(modifier = Modifier.height(32.dp))

        // Tombol Konfirmasi Utama
        Button(
            onClick = { handleNextStep() },
            modifier = Modifier.fillMaxWidth(),
            enabled = !isLoading
        ) {
            if (isLoading) {
                CircularProgressIndicator(modifier = Modifier.size(24.dp))
            } else {
                Text(if (step == 3) "UBAH PASSWORD" else "LANJUTKAN")
            }
        }

        Spacer(modifier = Modifier.height(16.dp))
        TextButton(onClick = onBack) { Text("Batal & Kembali") }
    }
}